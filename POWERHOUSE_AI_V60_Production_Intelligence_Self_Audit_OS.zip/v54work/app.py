from __future__ import annotations

import os
import re
import threading
import time
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.responses import FileResponse, HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

ROOT = Path(__file__).parent
STATIC = ROOT / "static"
load_dotenv(ROOT / ".env")

from upstox_service import UpstoxError, UpstoxService  # noqa: E402
from ai_engine import AIFusionEngine  # noqa: E402
from demo_data import demo_snapshot  # noqa: E402
from index_brain import INDEX_UNIVERSES  # noqa: E402
from smart_money import analyse_smart_money
from candle_intel import analyse_candles  # noqa: E402
from nse_oi import fetch_nse_oi_spurts  # noqa: E402
from market_intel import analyse_market_intel  # noqa: E402
from opportunity_engine import build_opportunity_radar  # noqa: E402
from supreme_engine import build_supreme_intelligence  # noqa: E402
from v53_engine import build_v53  # noqa: E402
from v54_engine import build_v54, stock_option_heatmap  # noqa: E402
from v55_engine import build_v55  # noqa: E402
from v56_engine import build_v56, apply_custom_scan  # noqa: E402
from v57_engine import build_v57  # noqa: E402
from v58_engine import build_v58  # noqa: E402
from v60_engine import build_v60, record_outcome  # noqa: E402

ai_engine = AIFusionEngine()

# Multi-device isolation: every browser/PWA installation gets its own UpstoxService.
# Device IDs are random values generated locally by the frontend and contain no personal data.
_services: dict[str, UpstoxService] = {}
_services_lock = threading.RLock()
_oauth_sessions: dict[str, str] = {}
RUNTIME = ROOT / ".runtime" / "devices"

def _clean_device_id(raw: str | None) -> str:
    raw = (raw or "").strip()
    if not raw:
        return "default"
    cleaned = re.sub(r"[^A-Za-z0-9_-]", "", raw)[:80]
    return cleaned or "default"

def service_for(device_id: str | None) -> UpstoxService:
    key = _clean_device_id(device_id)
    with _services_lock:
        svc = _services.get(key)
        if svc is None:
            token_file = RUNTIME / key / "upstox_token.json"
            svc = UpstoxService(token_file=token_file)
            _services[key] = svc
            if svc.authenticated:
                svc.start_background()
        return svc

def request_service(request: Request) -> UpstoxService:
    return service_for(request.headers.get("X-Device-ID"))
app = FastAPI(title="Powerhouse AI V60 — Production Intelligence & Self-Audit OS", version="60.0")
app.mount("/static", StaticFiles(directory=STATIC), name="static")


class TokenBody(BaseModel):
    access_token: str
    persist: bool = True


class ExpiryBody(BaseModel):
    expiry: str

class UnderlyingBody(BaseModel):
    code: str


@app.on_event("startup")
def startup() -> None:
    # Device services are created lazily on first request.
    pass


@app.on_event("shutdown")
def shutdown() -> None:
    with _services_lock:
        for svc in _services.values():
            svc.stop()


@app.get("/")
def root() -> FileResponse:
    return FileResponse(STATIC / "index.html", headers={"Cache-Control": "no-cache"})


@app.get("/manifest.webmanifest")
def manifest() -> FileResponse:
    return FileResponse(STATIC / "manifest.webmanifest", media_type="application/manifest+json")


@app.get("/sw.js")
def sw() -> FileResponse:
    return FileResponse(STATIC / "sw.js", media_type="application/javascript", headers={"Cache-Control": "no-cache"})


@app.get("/api/upstox/status")
def status(request: Request):
    return request_service(request).status()


@app.get("/api/upstox/login")
def login(device_id: str = Query("default")):
    svc = service_for(device_id)
    try:
        url = svc.oauth_login_url()
        if svc.oauth_state:
            _oauth_sessions[svc.oauth_state] = _clean_device_id(device_id)
        return RedirectResponse(url, status_code=302)
    except UpstoxError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.get("/api/upstox/callback")
def callback(code: str = Query(...), state: Optional[str] = None):
    try:
        device_id = _oauth_sessions.pop(state or "", "default")
        service_for(device_id).exchange_code(code, state)
        return HTMLResponse(
            """
            <html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head>
            <body style='font-family:system-ui;background:#071018;color:#fff;padding:28px'>
            <h2>Upstox connected.</h2>
            <p>Returning to NIFTY Powerhouse AI Index Brain…</p>
            <script>setTimeout(()=>{location.href='/'},900)</script>
            </body></html>
            """
        )
    except UpstoxError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.post("/api/upstox/manual-token")
def manual_token(body: TokenBody, request: Request):
    svc = request_service(request)
    try:
        svc.set_manual_token(body.access_token, body.persist)
        return {"ok": True, "status": svc.status()}
    except UpstoxError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.post("/api/upstox/logout")
def logout(request: Request):
    request_service(request).clear_token()
    return {"ok": True}


@app.get("/api/upstox/expiries")
def expiries(request: Request, force: bool = False):
    svc = request_service(request)
    try:
        return {"ok": True, "expiries": svc.fetch_expiries(force=force)}
    except UpstoxError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.post("/api/upstox/expiry")
def set_expiry(body: ExpiryBody, request: Request):
    svc = request_service(request)
    try:
        svc.set_expiry(body.expiry)
        return svc.snapshot()
    except UpstoxError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.post("/api/upstox/underlying")
def set_underlying(body: UnderlyingBody, request: Request):
    svc = request_service(request)
    if not svc.authenticated:
        raise HTTPException(status_code=401, detail="Connect Upstox first")
    try:
        svc.set_underlying(body.code)
        return svc.status()
    except UpstoxError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.get("/api/nse/oi-spurts")
def nse_oi_spurts():
    return fetch_nse_oi_spurts()


@app.post("/api/upstox/resync")
def resync(request: Request):
    svc = request_service(request)
    try:
        svc.sync_chain_rest()
        svc.sync_analytics()
        return svc.snapshot()
    except UpstoxError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.get("/api/health")
def health(request: Request):
    svc = request_service(request)
    return {
        "ok": True,
        "app": "Powerhouse AI V54",
        "institutional_footprints": True,
        "multi_device_laptop": True,
        "mode": "ai_index_brain_read_only_signals",
        "orders_enabled": False,
        "pnl_enabled": False,
        "execution_enabled": False,
        "upstox_authenticated": svc.authenticated,
        "multi_device": True,
    }


@app.get("/api/index/weights")
def index_weights():
    """Read-only constituent/weight metadata used by Index Brain."""
    return {
        code: {
            "label": cfg["label"],
            "weights_as_of": cfg["weights_as_of"],
            "weights_source": cfg["weights_source"],
            "tracked_weight_pct": round(sum(float(x["weight"]) for x in cfg["stocks"]), 2),
            "stocks": cfg["stocks"],
        }
        for code, cfg in INDEX_UNIVERSES.items()
    }


@app.get("/api/upstox/diagnostics")
def diagnostics(request: Request):
    svc = request_service(request)
    if not svc.authenticated:
        raise HTTPException(status_code=401, detail="Connect Upstox first")
    return svc.diagnostics()


@app.get("/api/upstox/snapshot")
def snapshot(request: Request):
    svc = request_service(request)
    if not svc.authenticated:
        raise HTTPException(status_code=401, detail="Connect Upstox first")
    snap = svc.snapshot()
    if not snap.get("option_data"):
        try:
            svc.sync_chain_rest()
            snap = svc.snapshot()
        except UpstoxError as exc:
            raise HTTPException(status_code=400, detail=str(exc))
    return snap


@app.get("/api/ai/snapshot")
def ai_snapshot(request: Request, mode: str = Query("strict", pattern="^(strict|balanced|fast)$")):
    svc = request_service(request)
    if not svc.authenticated:
        raise HTTPException(status_code=401, detail="Connect Upstox first")
    snap = svc.snapshot()
    if not snap.get("option_data"):
        try:
            svc.sync_chain_rest()
            svc.sync_analytics()
            snap = svc.snapshot()
        except UpstoxError as exc:
            raise HTTPException(status_code=400, detail=str(exc))
    ai = ai_engine.analyse(snap, mode=mode)
    sm = analyse_smart_money(snap)
    radar = build_opportunity_radar(snap, ai, sm)
    v50 = build_supreme_intelligence(snap, ai, sm, radar)
    v53 = build_v53(snap, ai, sm, radar, v50)
    return {"market": snap, "ai": ai, "smart_money": sm, "market_intel": analyse_market_intel(snap, ai, sm), "v31": radar, "v50": v50, "v53": v53, "v54": build_v54(snap, ai, sm, radar, v53), "v55": build_v55(snap, v53), "v56": build_v56(snap, build_v55(snap, v53)), "v57": build_v57(snap, build_v56(snap, build_v55(snap, v53))), "v58": build_v58(snap, build_v57(snap, build_v56(snap, build_v55(snap, v53)))), "v60": build_v60(snap, build_v58(snap, build_v57(snap, build_v56(snap, build_v55(snap, v53)))))}



@app.get("/api/chart/candles")
def chart_candles(request: Request, interval: int = Query(5), limit: int = Query(120)):
    svc = request_service(request)
    if not svc.authenticated:
        raise HTTPException(status_code=401, detail="Connect Upstox first")
    try:
        rows = svc.intraday_candles(interval=interval, limit=limit)
        out = analyse_candles(rows)
        out.update({"interval": interval, "underlying": getattr(svc, "active_underlying", "NIFTY"), "read_only": True})
        return out
    except UpstoxError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.get("/api/smart-money")
def smart_money(request: Request):
    svc = request_service(request)
    if not svc.authenticated:
        raise HTTPException(status_code=401, detail="Connect Upstox first")
    return analyse_smart_money(svc.snapshot())

@app.get("/api/ai/demo")
def ai_demo(mode: str = Query("strict", pattern="^(strict|balanced|fast)$")):
    snap = demo_snapshot()
    ai = ai_engine.analyse(snap, mode=mode)
    sm = analyse_smart_money(snap)
    radar = build_opportunity_radar(snap, ai, sm)
    v50 = build_supreme_intelligence(snap, ai, sm, radar)
    v53 = build_v53(snap, ai, sm, radar, v50)
    return {"market": snap, "ai": ai, "smart_money": sm, "market_intel": analyse_market_intel(snap, ai, sm), "v31": radar, "v50": v50, "v53": v53, "v54": build_v54(snap, ai, sm, radar, v53), "v55": build_v55(snap, v53), "v56": build_v56(snap, build_v55(snap, v53)), "v57": build_v57(snap, build_v56(snap, build_v55(snap, v53))), "v58": build_v58(snap, build_v57(snap, build_v56(snap, build_v55(snap, v53)))), "v60": build_v60(snap, build_v58(snap, build_v57(snap, build_v56(snap, build_v55(snap, v53))))), "demo": True}


@app.post("/api/v60/outcome")
async def v60_outcome(request: Request):
    """Read-only diagnostic hook for verified post-move/session-replay outcomes. Never places orders."""
    body = await request.json()
    try:
        ev = record_outcome(
            body.get("symbol"),
            body.get("category"),
            body.get("detail", ""),
            body.get("move_pct"),
            body.get("detected_epoch"),
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {"ok": True, "read_only": True, "event": ev}

@app.get("/api/v60/status")
def v60_status(request: Request):
    svc = request_service(request)
    if not svc.authenticated:
        raise HTTPException(status_code=401, detail="Connect Upstox first")
    snap=svc.snapshot(); ai=ai_engine.analyse(snap, mode="strict"); sm=analyse_smart_money(snap)
    radar=build_opportunity_radar(snap, ai, sm); v50=build_supreme_intelligence(snap, ai, sm, radar); v53=build_v53(snap, ai, sm, radar, v50)
    v55=build_v55(snap,v53); v56=build_v56(snap,v55); v57=build_v57(snap,v56); v58=build_v58(snap,v57); v60=build_v60(snap,v58)
    return {"ok":True,"read_only":True,"version":"60.0","production_readiness":v60.get("production_readiness"),"scanner_health":v60.get("scanner_health"),"detection_benchmark":v60.get("detection_benchmark")}


@app.get("/api/v31/stock-option")
def v31_stock_option(request: Request, symbol: str = Query(..., min_length=1, max_length=30)):
    """On-demand stock-option resolver. Read-only and intentionally not polled continuously."""
    svc = request_service(request)
    if not svc.authenticated:
        raise HTTPException(status_code=401, detail="Connect Upstox first")
    symbol = re.sub(r"[^A-Za-z0-9&.-]", "", symbol.upper())
    try:
        eq = svc._search_equity(symbol)
        key = (eq or {}).get("instrument_key")
        if not key:
            raise UpstoxError(f"NSE equity instrument not found for {symbol}")
        contracts = svc.get(f"https://api.upstox.com/v2/option/contract", params={"instrument_key": key}).get("data") or []
        expiries = sorted({str(x.get("expiry")) for x in contracts if x.get("expiry")})
        if not expiries:
            return {"ok":False,"symbol":symbol,"reason":"No listed option expiry returned for this instrument"}
        expiry=expiries[0]
        chain = svc.get("https://api.upstox.com/v2/option/chain", params={"instrument_key":key,"expiry_date":expiry}).get("data") or []
        compact=[]
        for item in chain:
            c=item.get("call_options") or {}; p=item.get("put_options") or {}; cm=c.get("market_data") or {}; pm=p.get("market_data") or {}
            compact.append({"strike":item.get("strike_price"),"spot":item.get("underlying_spot_price"),
              "ce":{"ltp":cm.get("ltp"),"oi":cm.get("oi"),"volume":cm.get("volume"),"bid":cm.get("bid_price"),"ask":cm.get("ask_price"),"key":c.get("instrument_key")},
              "pe":{"ltp":pm.get("ltp"),"oi":pm.get("oi"),"volume":pm.get("volume"),"bid":pm.get("bid_price"),"ask":pm.get("ask_price"),"key":p.get("instrument_key")}})
        return {"ok":True,"symbol":symbol,"instrument_key":key,"expiry":expiry,"expiries":expiries[:8],"chain":compact,"read_only":True}
    except UpstoxError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.get("/api/v54/stock-option-heatmap")
def v54_stock_option_heatmap(request: Request, symbol: str = Query(..., min_length=1, max_length=30), expiry: Optional[str] = None):
    """On-demand F&O stock option heatmap. No continuous full-market chain polling."""
    svc = request_service(request)
    if not svc.authenticated:
        raise HTTPException(status_code=401, detail="Connect Upstox first")
    symbol = re.sub(r"[^A-Za-z0-9&.-]", "", symbol.upper())
    try:
        eq = svc._search_equity(symbol)
        key = (eq or {}).get("instrument_key")
        if not key:
            raise UpstoxError(f"NSE equity instrument not found for {symbol}")
        contracts = svc.get("https://api.upstox.com/v2/option/contract", params={"instrument_key": key}).get("data") or []
        expiries = sorted({str(x.get("expiry")) for x in contracts if x.get("expiry")})
        if not expiries:
            return {"ok":False,"symbol":symbol,"reason":"No listed option expiry returned for this instrument"}
        chosen = expiry if expiry in expiries else expiries[0]
        chain = svc.get("https://api.upstox.com/v2/option/chain", params={"instrument_key":key,"expiry_date":chosen}).get("data") or []
        compact=[]
        for item in chain:
            c=item.get("call_options") or {}; p=item.get("put_options") or {}
            cm=c.get("market_data") or {}; pm=p.get("market_data") or {}
            cg=c.get("option_greeks") or {}; pg=p.get("option_greeks") or {}
            compact.append({"strike":item.get("strike_price"),"spot":item.get("underlying_spot_price"),
              "ce":{"ltp":cm.get("ltp"),"oi":cm.get("oi"),"delta_oi":cm.get("oi")-cm.get("prev_oi") if isinstance(cm.get("oi"),(int,float)) and isinstance(cm.get("prev_oi"),(int,float)) else None,"volume":cm.get("volume"),"bid":cm.get("bid_price"),"ask":cm.get("ask_price"),"bid_qty":cm.get("bid_qty"),"ask_qty":cm.get("ask_qty"),"iv":cg.get("iv"),"delta":cg.get("delta"),"gamma":cg.get("gamma"),"theta":cg.get("theta"),"vega":cg.get("vega")},
              "pe":{"ltp":pm.get("ltp"),"oi":pm.get("oi"),"delta_oi":pm.get("oi")-pm.get("prev_oi") if isinstance(pm.get("oi"),(int,float)) and isinstance(pm.get("prev_oi"),(int,float)) else None,"volume":pm.get("volume"),"bid":pm.get("bid_price"),"ask":pm.get("ask_price"),"bid_qty":pm.get("bid_qty"),"ask_qty":pm.get("ask_qty"),"iv":pg.get("iv"),"delta":pg.get("delta"),"gamma":pg.get("gamma"),"theta":pg.get("theta"),"vega":pg.get("vega")}})
        out=stock_option_heatmap(symbol, chosen, compact)
        out.update({"ok":True,"instrument_key":key,"expiries":expiries[:8]})
        return out
    except UpstoxError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.get("/api/v56/screener")
def v56_screener(request: Request, field: str = Query("setup_score"), op: str = Query("gte", pattern="^(gt|gte|lt|lte|eq)$"), value: float = Query(70)):
    """Read-only custom stock screener over verified live snapshot fields."""
    svc=request_service(request)
    if not svc.authenticated:
        raise HTTPException(status_code=401, detail="Connect Upstox first")
    snap=svc.snapshot()
    ai=ai_engine.analyse(snap, mode="balanced")
    sm=analyse_smart_money(snap); radar=build_opportunity_radar(snap,ai,sm); v50=build_supreme_intelligence(snap,ai,sm,radar); v53=build_v53(snap,ai,sm,radar,v50); v55=build_v55(snap,v53); v56=build_v56(snap,v55)
    rows=(v56.get("advanced_screener") or {}).get("universe") or []
    allowed=(v56.get("advanced_screener") or {}).get("available_fields") or []
    if field not in allowed:
        raise HTTPException(status_code=400, detail=f"Unsupported field. Allowed: {', '.join(allowed)}")
    return {"ok":True,"field":field,"operator":op,"value":value,"matches":apply_custom_scan(rows,field,op,value),"read_only":True}


if __name__ == "__main__":
    import uvicorn

    host = os.getenv("UPSTOX_HOST") or os.getenv("HOST") or "0.0.0.0"
    port = int(os.getenv("UPSTOX_PORT") or os.getenv("PORT") or "8787")
    print(f"Powerhouse AI V54 running at http://{host}:{port}")
    uvicorn.run("app:app", host=host, port=port, reload=False)

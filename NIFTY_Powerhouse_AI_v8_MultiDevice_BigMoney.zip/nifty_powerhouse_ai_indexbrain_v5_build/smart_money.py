from __future__ import annotations
from datetime import datetime
from math import isfinite

def _n(v, d=0.0):
    try:
        x=float(v)
        return x if isfinite(x) else d
    except Exception:
        return d

def _clamp(v, a=0.0, b=100.0):
    return max(a, min(b, v))

def analyse_smart_money(snapshot: dict) -> dict:
    """Institutional-footprint inference from live market microstructure.

    IMPORTANT: this does NOT identify a particular FII/DII participant. It is a
    proxy built from option-chain OI/volume, heavyweight/index internals and
    price structure. Official FII/DII cash-flow data should be treated separately.
    """
    rows = snapshot.get("option_data") or []
    spot = _n(snapshot.get("spot"))
    call_vol = sum(_n(r.get("cvol")) for r in rows)
    put_vol = sum(_n(r.get("pvol")) for r in rows)
    call_oi = sum(_n(r.get("coi")) for r in rows)
    put_oi = sum(_n(r.get("poi")) for r in rows)
    call_doi = sum(_n(r.get("cdoi", r.get("coi_change", 0))) for r in rows)
    put_doi = sum(_n(r.get("pdoi", r.get("poi_change", 0))) for r in rows)

    vol_bias = (put_vol-call_vol) / max(put_vol+call_vol, 1)
    oi_bias = (put_oi-call_oi) / max(put_oi+call_oi, 1)
    doi_bias = (put_doi-call_doi) / max(abs(put_doi)+abs(call_doi), 1)

    ib = snapshot.get("index_brain") or {}
    nifty = ib.get("NIFTY") or {}
    bank = ib.get("BANKNIFTY") or {}
    nscore = _n(nifty.get("direction_score"), 50)
    bscore = _n(bank.get("direction_score"), 50)
    heavy_bias = ((nscore-50)+(bscore-50))/100.0
    divergence = max(_n(nifty.get("divergence_risk")), _n(bank.get("divergence_risk")))

    raw = 50 + 22*vol_bias + 18*oi_bias + 15*doi_bias + 25*heavy_bias
    score = _clamp(raw)
    if score >= 60:
        direction = "BULLISH FOOTPRINT"
    elif score <= 40:
        direction = "BEARISH FOOTPRINT"
    else:
        direction = "MIXED / ABSORPTION"

    whale = []
    for r in rows:
        s=_n(r.get("s"))
        for side, vol, oi, doi, ltp in (
            ("CE", _n(r.get("cvol")), _n(r.get("coi")), _n(r.get("cdoi",0)), _n(r.get("cltp"))),
            ("PE", _n(r.get("pvol")), _n(r.get("poi")), _n(r.get("pdoi",0)), _n(r.get("pltp"))),
        ):
            liq = (vol ** .5) + (oi ** .5) + (abs(doi) ** .5)
            whale.append({"strike":s,"side":side,"volume":vol,"oi":oi,"delta_oi":doi,"ltp":ltp,"activity_score":liq})
    whale.sort(key=lambda x:x["activity_score"], reverse=True)
    whale = whale[:6]

    call_wall = max(rows, key=lambda r:_n(r.get("coi")), default={})
    put_wall = max(rows, key=lambda r:_n(r.get("poi")), default={})
    call_wall_s = _n(call_wall.get("s")) or None
    put_wall_s = _n(put_wall.get("s")) or None

    # Absorption: heavy activity while broad directional evidence remains conflicted.
    activity = call_vol + put_vol
    absorption = _clamp((100-abs(score-50)*2)*0.55 + min(45, activity/250000))
    trap = _clamp(divergence*0.65 + absorption*0.35)

    now = datetime.now()
    mins = now.hour*60+now.minute
    if mins < 9*60+15: phase="PRE-OPEN"
    elif mins < 10*60: phase="OPENING DISCOVERY"
    elif mins < 13*60: phase="MID-SESSION"
    elif mins < 14*60+30: phase="POSITIONING"
    elif mins < 15*60+30: phase="CLOSING FLOW"
    else: phase="AFTER MARKET"

    return {
        "engine":"Big Money Footprints v8",
        "direction":direction,
        "footprint_score":round(score,1),
        "bull_pressure":round(score,1),
        "bear_pressure":round(100-score,1),
        "option_volume_bias":round(vol_bias*100,1),
        "option_oi_bias":round(oi_bias*100,1),
        "delta_oi_bias":round(doi_bias*100,1),
        "heavyweight_confirmation":round(_clamp(50+heavy_bias*50),1),
        "divergence_risk":round(divergence,1),
        "absorption_risk":round(absorption,1),
        "trap_risk":round(trap,1),
        "call_wall":call_wall_s,
        "put_wall":put_wall_s,
        "whale_strikes":whale,
        "session_phase":phase,
        "data_scope":"LIVE MARKET FOOTPRINT PROXY",
        "identity_warning":"This engine infers institutional-style pressure; it cannot identify a specific FII/DII from anonymous exchange market data.",
        "official_fii_dii":"NOT CLAIMED AS REAL-TIME FII/DII IDENTITY",
    }

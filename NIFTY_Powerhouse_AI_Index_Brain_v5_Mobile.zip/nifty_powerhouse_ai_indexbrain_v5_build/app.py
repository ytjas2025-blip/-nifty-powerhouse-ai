from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import FileResponse, HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

ROOT = Path(__file__).parent
STATIC = ROOT / "static"
load_dotenv(ROOT / ".env")

from upstox_service import UpstoxError, UpstoxService  # noqa: E402
from ai_engine import AIFusionEngine  # noqa: E402
from demo_data import demo_snapshot  # noqa: E402
from index_brain import INDEX_UNIVERSES  # noqa: E402

service = UpstoxService()
ai_engine = AIFusionEngine()
app = FastAPI(title="NIFTY Powerhouse AI Index Brain v5 — Upstox Read-Only", version="5.0")
app.mount("/static", StaticFiles(directory=STATIC), name="static")


class TokenBody(BaseModel):
    access_token: str
    persist: bool = True


class ExpiryBody(BaseModel):
    expiry: str


@app.on_event("startup")
def startup() -> None:
    if service.authenticated:
        service.start_background()


@app.on_event("shutdown")
def shutdown() -> None:
    service.stop()


@app.get("/")
def root() -> FileResponse:
    return FileResponse(STATIC / "index.html", headers={"Cache-Control": "no-cache"})


@app.get("/manifest.webmanifest")
def manifest() -> FileResponse:
    return FileResponse(STATIC / "manifest.webmanifest", media_type="application/manifest+json")


@app.get("/sw.js")
def sw() -> FileResponse:
    return FileResponse(STATIC / "sw.js", media_type="application/javascript", headers={"Cache-Control": "no-cache"})


@app.get("/api/upstox/status")
def status():
    return service.status()


@app.get("/api/upstox/login")
def login():
    try:
        return RedirectResponse(service.oauth_login_url(), status_code=302)
    except UpstoxError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.get("/api/upstox/callback")
def callback(code: str = Query(...), state: Optional[str] = None):
    try:
        service.exchange_code(code, state)
        return HTMLResponse(
            """
            <html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head>
            <body style='font-family:system-ui;background:#071018;color:#fff;padding:28px'>
            <h2>Upstox connected.</h2>
            <p>Returning to NIFTY Powerhouse AI Index Brain…</p>
            <script>setTimeout(()=>{location.href='/'},900)</script>
            </body></html>
            """
        )
    except UpstoxError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.post("/api/upstox/manual-token")
def manual_token(body: TokenBody):
    try:
        service.set_manual_token(body.access_token, body.persist)
        return {"ok": True, "status": service.status()}
    except UpstoxError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.post("/api/upstox/logout")
def logout():
    service.clear_token()
    return {"ok": True}


@app.get("/api/upstox/expiries")
def expiries(force: bool = False):
    try:
        return {"ok": True, "expiries": service.fetch_expiries(force=force)}
    except UpstoxError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.post("/api/upstox/expiry")
def set_expiry(body: ExpiryBody):
    try:
        service.set_expiry(body.expiry)
        return service.snapshot()
    except UpstoxError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.post("/api/upstox/resync")
def resync():
    try:
        service.sync_chain_rest()
        service.sync_analytics()
        return service.snapshot()
    except UpstoxError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.get("/api/health")
def health():
    return {
        "ok": True,
        "app": "NIFTY Powerhouse AI Index Brain v5",
        "mode": "ai_index_brain_read_only_signals",
        "orders_enabled": False,
        "pnl_enabled": False,
        "execution_enabled": False,
        "upstox_authenticated": service.authenticated,
    }


@app.get("/api/index/weights")
def index_weights():
    """Read-only constituent/weight metadata used by Index Brain."""
    return {
        code: {
            "label": cfg["label"],
            "weights_as_of": cfg["weights_as_of"],
            "weights_source": cfg["weights_source"],
            "tracked_weight_pct": round(sum(float(x["weight"]) for x in cfg["stocks"]), 2),
            "stocks": cfg["stocks"],
        }
        for code, cfg in INDEX_UNIVERSES.items()
    }


@app.get("/api/upstox/diagnostics")
def diagnostics():
    if not service.authenticated:
        raise HTTPException(status_code=401, detail="Connect Upstox first")
    return service.diagnostics()


@app.get("/api/upstox/snapshot")
def snapshot():
    if not service.authenticated:
        raise HTTPException(status_code=401, detail="Connect Upstox first")
    snap = service.snapshot()
    if not snap.get("option_data"):
        try:
            service.sync_chain_rest()
            snap = service.snapshot()
        except UpstoxError as exc:
            raise HTTPException(status_code=400, detail=str(exc))
    return snap


@app.get("/api/ai/snapshot")
def ai_snapshot(mode: str = Query("strict", pattern="^(strict|balanced|fast)$")):
    if not service.authenticated:
        raise HTTPException(status_code=401, detail="Connect Upstox first")
    snap = service.snapshot()
    if not snap.get("option_data"):
        try:
            service.sync_chain_rest()
            service.sync_analytics()
            snap = service.snapshot()
        except UpstoxError as exc:
            raise HTTPException(status_code=400, detail=str(exc))
    return {"market": snap, "ai": ai_engine.analyse(snap, mode=mode)}


@app.get("/api/ai/demo")
def ai_demo(mode: str = Query("strict", pattern="^(strict|balanced|fast)$")):
    snap = demo_snapshot()
    return {"market": snap, "ai": ai_engine.analyse(snap, mode=mode), "demo": True}


if __name__ == "__main__":
    import uvicorn

    host = os.getenv("UPSTOX_HOST") or os.getenv("HOST") or "0.0.0.0"
    port = int(os.getenv("UPSTOX_PORT") or os.getenv("PORT") or "8787")
    print(f"NIFTY Powerhouse AI Index Brain v5 running at http://{host}:{port}")
    uvicorn.run("app:app", host=host, port=port, reload=False)

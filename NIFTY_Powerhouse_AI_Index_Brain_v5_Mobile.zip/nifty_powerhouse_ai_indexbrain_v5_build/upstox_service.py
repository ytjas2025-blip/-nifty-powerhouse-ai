from __future__ import annotations

import json
import math
import os
import secrets
import statistics
import threading
import time
from collections import defaultdict, deque
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Deque, Dict, Iterable, List, Optional, Tuple
from urllib.parse import quote, urlencode

import httpx

from index_brain import INDEX_UNIVERSES, all_symbols, analyse_index_brains

IST = timezone(timedelta(hours=5, minutes=30))
BASE_V2 = "https://api.upstox.com/v2"
BASE_V3 = "https://api.upstox.com/v3"
NIFTY_KEY_DEFAULT = "NSE_INDEX|Nifty 50"
TOKEN_FILE = Path(__file__).parent / ".runtime" / "upstox_token.json"

BANKNIFTY_KEY_DEFAULT = "NSE_INDEX|Nifty Bank"



def now_ist() -> datetime:
    return datetime.now(IST)


def truthy(v: Optional[str], default: bool = False) -> bool:
    if v is None:
        return default
    return v.strip().lower() in {"1", "true", "yes", "on"}


def safe_float(v: Any, default: float = 0.0) -> float:
    try:
        if v is None or v == "":
            return default
        return float(v)
    except Exception:
        return default


def pct_change(ltp: float, close: float) -> float:
    if not close:
        return 0.0
    return (ltp - close) / close * 100.0


def clamp(x: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, x))


@dataclass
class Tick:
    ts: float
    volume: float
    oi: float
    ltp: float


class UpstoxError(RuntimeError):
    pass


class UpstoxService:
    """Live Upstox market-data bridge for the NIFTY Powerhouse UI.

    Design:
    - REST option-chain bootstraps the full chain and periodically resynchronizes OI/prev OI.
    - MarketDataStreamerV3, when available, updates LTP/depth/volume/OI/IV/Greeks in real time.
    - If the SDK/websocket is unavailable, the service falls back to a slower REST sync.
    - Browser never receives API secret; access token stays in the local backend process.
    """

    def __init__(self) -> None:
        self.api_key = (os.getenv("UPSTOX_API_KEY") or os.getenv("UPSTOX_CLIENT_ID") or "").strip()
        self.api_secret = (os.getenv("UPSTOX_API_SECRET") or os.getenv("UPSTOX_CLIENT_SECRET") or "").strip()
        self.redirect_uri = os.getenv(
            "UPSTOX_REDIRECT_URI", "http://127.0.0.1:8787/api/upstox/callback"
        ).strip()
        self.underlying_key = os.getenv("UPSTOX_UNDERLYING_KEY", NIFTY_KEY_DEFAULT).strip()
        self.strike_window = max(3, int(os.getenv("UPSTOX_STRIKE_WINDOW", "12")))
        self.rest_sync_seconds = max(5, int(os.getenv("UPSTOX_REST_SYNC_SECONDS", "15")))
        self.analytics_sync_seconds = max(
            15, int(os.getenv("UPSTOX_ANALYTICS_SYNC_SECONDS", "45"))
        )
        self.enable_ws = truthy(os.getenv("UPSTOX_ENABLE_WEBSOCKET"), True)
        self.enable_breadth = truthy(os.getenv("UPSTOX_ENABLE_BREADTH"), True)

        self.lock = threading.RLock()
        self.stop_event = threading.Event()
        self.bg_thread: Optional[threading.Thread] = None
        self.ws_thread: Optional[threading.Thread] = None
        self.streamer = None
        self.streamer_connected = False
        self.streamer_error = ""
        self.subscribed_keys: set[str] = set()

        self.oauth_state: Optional[str] = None
        self.access_token = os.getenv("UPSTOX_ACCESS_TOKEN", "").strip()
        self.token_source = "env" if self.access_token else ""
        if not self.access_token:
            self._load_token_file()

        self.current_expiry: Optional[str] = None
        self.expiries: List[str] = []
        self.chain: Dict[float, Dict[str, Any]] = {}
        self.instrument_lookup: Dict[str, Tuple[float, str]] = {}
        self.history: Dict[str, Deque[Tick]] = defaultdict(lambda: deque(maxlen=1200))
        self.last_rest_sync = 0.0
        self.last_analytics_sync = 0.0
        self.last_message_ts = 0.0
        self.spot = 0.0
        self.spot_close = 0.0
        self.vwap = 0.0
        self.futures_key: Optional[str] = None
        self.futures_ltp = 0.0
        self.futures_atp = 0.0
        self.price_series: Dict[int, List[float]] = {3: [], 5: [], 15: []}
        self.official_max_pain: Optional[float] = None
        self.official_pcr: Optional[float] = None
        self.analytics_note = ""
        # High-weight constituent futures are shared across NIFTY/BANKNIFTY.
        # Each symbol is subscribed once, then re-weighted separately by Index Brain.
        self.heavy_futures: Dict[str, Dict[str, Any]] = {}
        self.breadth_ready = False
        self.index_levels: Dict[str, Dict[str, Any]] = {
            "NIFTY": {"instrument_key": self.underlying_key, "ltp": 0.0, "cp": 0.0},
            "BANKNIFTY": {"instrument_key": BANKNIFTY_KEY_DEFAULT, "ltp": 0.0, "cp": 0.0},
        }
        self.index_level_keys: Dict[str, str] = {
            self.underlying_key: "NIFTY",
            BANKNIFTY_KEY_DEFAULT: "BANKNIFTY",
        }
        self.iv_proxy = 50.0

        self.client = httpx.Client(timeout=12.0, follow_redirects=True)

    # ---------- token/auth ----------
    def _load_token_file(self) -> None:
        try:
            if TOKEN_FILE.exists():
                payload = json.loads(TOKEN_FILE.read_text())
                token = str(payload.get("access_token", "")).strip()
                if token:
                    self.access_token = token
                    self.token_source = "local_file"
        except Exception:
            pass

    def _save_token_file(self, token: str) -> None:
        TOKEN_FILE.parent.mkdir(parents=True, exist_ok=True)
        TOKEN_FILE.write_text(
            json.dumps(
                {
                    "access_token": token,
                    "saved_at": datetime.now(timezone.utc).isoformat(),
                },
                indent=2,
            )
        )
        try:
            os.chmod(TOKEN_FILE, 0o600)
        except Exception:
            pass

    def set_manual_token(self, token: str, persist: bool = True) -> None:
        token = token.strip()
        if len(token) < 20:
            raise UpstoxError("Access token looks too short.")
        with self.lock:
            old_token, old_source = self.access_token, self.token_source
            self.access_token = token
            self.token_source = "manual"
            self._reset_live_state_for_new_token()
        try:
            # Validate against a read-only option endpoint before saving. This works
            # for both standard OAuth tokens and the long-lived Analytics Token.
            self.fetch_expiries(force=True)
        except Exception:
            with self.lock:
                self.access_token, self.token_source = old_token, old_source
                self._reset_live_state_for_new_token()
            raise
        if persist:
            self._save_token_file(token)
        self.start_background()

    def clear_token(self) -> None:
        with self.lock:
            self.access_token = ""
            self.token_source = ""
            self._stop_streamer_locked()
            self.chain.clear()
            self.instrument_lookup.clear()
            self.current_expiry = None
        try:
            TOKEN_FILE.unlink(missing_ok=True)
        except Exception:
            pass

    def _reset_live_state_for_new_token(self) -> None:
        self._stop_streamer_locked()
        self.chain.clear()
        self.instrument_lookup.clear()
        self.expiries = []
        self.current_expiry = None
        self.last_rest_sync = 0
        self.last_analytics_sync = 0
        self.streamer_error = ""

    @property
    def configured_app(self) -> bool:
        return bool(self.api_key and self.api_secret and self.redirect_uri)

    @property
    def authenticated(self) -> bool:
        return bool(self.access_token)

    def oauth_login_url(self) -> str:
        if not self.api_key:
            raise UpstoxError("UPSTOX_API_KEY is missing in .env")
        state = secrets.token_urlsafe(24)
        self.oauth_state = state
        qs = urlencode(
            {
                "response_type": "code",
                "client_id": self.api_key,
                "redirect_uri": self.redirect_uri,
                "state": state,
            }
        )
        return f"{BASE_V2}/login/authorization/dialog?{qs}"

    def exchange_code(self, code: str, state: Optional[str]) -> Dict[str, Any]:
        if not self.configured_app:
            raise UpstoxError("API key, secret, or redirect URI is missing in .env")
        if self.oauth_state and state != self.oauth_state:
            raise UpstoxError("OAuth state mismatch. Start login again.")
        resp = self.client.post(
            f"{BASE_V2}/login/authorization/token",
            headers={
                "accept": "application/json",
                "Content-Type": "application/x-www-form-urlencoded",
            },
            data={
                "code": code,
                "client_id": self.api_key,
                "client_secret": self.api_secret,
                "redirect_uri": self.redirect_uri,
                "grant_type": "authorization_code",
            },
        )
        data = self._json_or_error(resp, "token exchange")
        token = str(data.get("access_token", "")).strip()
        if not token:
            raise UpstoxError("Upstox token response did not contain access_token")
        with self.lock:
            self.access_token = token
            self.token_source = "oauth"
            self._reset_live_state_for_new_token()
            self.oauth_state = None
        self._save_token_file(token)
        self.start_background()
        return data

    # ---------- HTTP ----------
    def _headers(self) -> Dict[str, str]:
        if not self.access_token:
            raise UpstoxError("Not authenticated with Upstox")
        return {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.access_token}",
        }

    def _json_or_error(self, resp: httpx.Response, label: str) -> Dict[str, Any]:
        try:
            payload = resp.json()
        except Exception:
            payload = {"raw": resp.text[:800]}
        if resp.status_code >= 400:
            msg = payload.get("message") or payload.get("errors") or payload.get("raw") or payload
            raise UpstoxError(f"Upstox {label} failed ({resp.status_code}): {msg}")
        if isinstance(payload, dict) and payload.get("status") == "error":
            raise UpstoxError(f"Upstox {label} error: {payload}")
        return payload

    def get(self, url: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        resp = self.client.get(url, params=params, headers=self._headers())
        return self._json_or_error(resp, url)

    # ---------- instrument discovery ----------
    def fetch_expiries(self, force: bool = False) -> List[str]:
        with self.lock:
            if self.expiries and not force:
                return list(self.expiries)
        payload = self.get(
            f"{BASE_V2}/option/contract", params={"instrument_key": self.underlying_key}
        )
        rows = payload.get("data") or []
        expiries = sorted({str(x.get("expiry")) for x in rows if x.get("expiry")})
        today = now_ist().date().isoformat()
        future = [x for x in expiries if x >= today]
        with self.lock:
            self.expiries = future or expiries
        return list(self.expiries)

    def _search_future(self, query: str) -> Optional[Dict[str, Any]]:
        try:
            payload = self.get(
                f"{BASE_V2}/instruments/search",
                params={
                    "query": query,
                    "exchanges": "NSE",
                    "segments": "FO",
                    "instrument_types": "FUT",
                    "expiry": "current_month",
                    "page_number": 1,
                    "records": 30,
                },
            )
            rows = payload.get("data") or []
            futs = [r for r in rows if r.get("instrument_type") == "FUT"]
            # Prefer an index future for NIFTY, exact underlying symbol for stocks.
            q = query.upper().replace(" ", "")
            futs.sort(
                key=lambda r: (
                    0
                    if str(r.get("underlying_symbol", "")).upper().replace(" ", "") == q
                    else 1,
                    str(r.get("expiry", "9999")),
                )
            )
            return futs[0] if futs else None
        except Exception:
            return None

    def discover_aux_instruments(self) -> None:
        if not self.authenticated:
            return
        if not self.futures_key:
            fut = self._search_future("NIFTY")
            if fut:
                self.futures_key = fut.get("instrument_key")
        if self.enable_breadth and not self.breadth_ready:
            found: Dict[str, Dict[str, Any]] = {}
            # Discover one current-month future per unique high-impact stock.
            # The same runtime price can feed multiple index weighting systems.
            for symbol in all_symbols():
                fut = self._search_future(symbol)
                if fut and fut.get("instrument_key"):
                    found[fut["instrument_key"]] = {
                        "query": symbol,
                        "name": symbol,
                        "instrument_key": fut["instrument_key"],
                        "ltp": 0.0,
                        "cp": 0.0,
                    }
            with self.lock:
                self.heavy_futures = found
                self.breadth_ready = bool(found)

    # ---------- chain ----------
    def sync_chain_rest(self, expiry: Optional[str] = None) -> None:
        if not self.authenticated:
            return
        if expiry:
            self.current_expiry = expiry
        if not self.current_expiry:
            exps = self.fetch_expiries()
            if not exps:
                raise UpstoxError("No NIFTY option expiries returned by Upstox")
            self.current_expiry = exps[0]

        payload = self.get(
            f"{BASE_V2}/option/chain",
            params={
                "instrument_key": self.underlying_key,
                "expiry_date": self.current_expiry,
            },
        )
        rows = payload.get("data") or []
        if not rows:
            raise UpstoxError("Upstox option chain returned no rows")

        new_chain: Dict[float, Dict[str, Any]] = {}
        new_lookup: Dict[str, Tuple[float, str]] = {}
        spot = safe_float(rows[0].get("underlying_spot_price"), self.spot)

        for item in rows:
            strike = safe_float(item.get("strike_price"))
            if not strike:
                continue
            c = item.get("call_options") or {}
            p = item.get("put_options") or {}
            cm = c.get("market_data") or {}
            pm = p.get("market_data") or {}
            cg = c.get("option_greeks") or {}
            pg = p.get("option_greeks") or {}

            c_oi_raw = safe_float(cm.get("oi"))
            p_oi_raw = safe_float(pm.get("oi"))
            c_prev_raw = safe_float(cm.get("prev_oi"), c_oi_raw)
            p_prev_raw = safe_float(pm.get("prev_oi"), p_oi_raw)
            c_oi = c_oi_raw / 100000.0
            p_oi = p_oi_raw / 100000.0
            c_prev = c_prev_raw / 100000.0
            p_prev = p_prev_raw / 100000.0
            c_ltp = safe_float(cm.get("ltp"))
            p_ltp = safe_float(pm.get("ltp"))
            c_close = safe_float(cm.get("close_price"), c_ltp)
            p_close = safe_float(pm.get("close_price"), p_ltp)
            c_iv = safe_float(cg.get("iv"))
            p_iv = safe_float(pg.get("iv"))
            if c_iv and c_iv < 2:
                c_iv *= 100
            if p_iv and p_iv < 2:
                p_iv *= 100

            row = {
                "s": strike,
                "coi": c_oi,
                "cchg": c_oi - c_prev,
                "cvol": safe_float(cm.get("volume")),
                "cltp": c_ltp,
                "cp": pct_change(c_ltp, c_close),
                "civ": c_iv,
                "c_delta": safe_float(cg.get("delta")),
                "c_gamma": safe_float(cg.get("gamma")),
                "c_theta": safe_float(cg.get("theta")),
                "c_vega": safe_float(cg.get("vega")),
                "poi": p_oi,
                "pchg": p_oi - p_prev,
                "pvol": safe_float(pm.get("volume")),
                "pltp": p_ltp,
                "pp": pct_change(p_ltp, p_close),
                "piv": p_iv,
                "p_delta": safe_float(pg.get("delta")),
                "p_gamma": safe_float(pg.get("gamma")),
                "p_theta": safe_float(pg.get("theta")),
                "p_vega": safe_float(pg.get("vega")),
                "cbid": safe_float(cm.get("bid_price"), c_ltp),
                "cask": safe_float(cm.get("ask_price"), c_ltp),
                "cbidq": safe_float(cm.get("bid_qty")),
                "caskq": safe_float(cm.get("ask_qty")),
                "pbid": safe_float(pm.get("bid_price"), p_ltp),
                "pask": safe_float(pm.get("ask_price"), p_ltp),
                "pbidq": safe_float(pm.get("bid_qty")),
                "paskq": safe_float(pm.get("ask_qty")),
                "call_key": c.get("instrument_key"),
                "put_key": p.get("instrument_key"),
                "call_close": c_close,
                "put_close": p_close,
            }
            new_chain[strike] = row
            if row["call_key"]:
                new_lookup[row["call_key"]] = (strike, "C")
                self._record_history(row["call_key"], row["cvol"], row["coi"], row["cltp"])
            if row["put_key"]:
                new_lookup[row["put_key"]] = (strike, "P")
                self._record_history(row["put_key"], row["pvol"], row["poi"], row["pltp"])

        with self.lock:
            # Preserve freshest websocket fields if the same strike already exists.
            old = self.chain
            for strike, row in new_chain.items():
                prev = old.get(strike)
                if prev and self.streamer_connected:
                    for key in (
                        "cltp",
                        "cvol",
                        "coi",
                        "civ",
                        "cbid",
                        "cask",
                        "cbidq",
                        "caskq",
                        "pltp",
                        "pvol",
                        "poi",
                        "piv",
                        "pbid",
                        "pask",
                        "pbidq",
                        "paskq",
                    ):
                        if prev.get(key) not in (None, 0, 0.0):
                            row[key] = prev[key]
                self.chain[strike] = row
            # replace, do not leave expired/out-of-scope rows behind
            self.chain = {k: self.chain[k] for k in new_chain.keys()}
            self.instrument_lookup = new_lookup
            self.spot = spot or self.spot
            if self.spot:
                self.index_levels["NIFTY"]["ltp"] = self.spot
            self.last_rest_sync = time.time()
            self._refresh_iv_proxy_locked()
        self.discover_aux_instruments()
        self._ensure_streamer_subscriptions()

    def set_expiry(self, expiry: str) -> None:
        if not expiry:
            raise UpstoxError("Expiry is required")
        with self.lock:
            changed = expiry != self.current_expiry
            self.current_expiry = expiry
            if changed:
                self.chain.clear()
                self.instrument_lookup.clear()
        self.sync_chain_rest(expiry)

    def _refresh_iv_proxy_locked(self) -> None:
        vals: List[float] = []
        for r in self.chain.values():
            for k in ("civ", "piv"):
                v = safe_float(r.get(k))
                if 1 <= v <= 300:
                    vals.append(v)
        if vals:
            med = statistics.median(vals)
            # Explicitly a regime proxy, not a historical IV rank.
            self.iv_proxy = clamp(15 + (med - 8) * 2.5, 5, 95)

    # ---------- live stream ----------
    def _selected_option_keys_locked(self) -> List[str]:
        if not self.chain:
            return []
        strikes = sorted(self.chain)
        spot = self.spot or statistics.median(strikes)
        idx = min(range(len(strikes)), key=lambda i: abs(strikes[i] - spot))
        lo = max(0, idx - self.strike_window)
        hi = min(len(strikes), idx + self.strike_window + 1)
        keys: List[str] = []
        for strike in strikes[lo:hi]:
            r = self.chain[strike]
            if r.get("call_key"):
                keys.append(r["call_key"])
            if r.get("put_key"):
                keys.append(r["put_key"])
        return keys

    def _desired_subscription_keys_locked(self) -> set[str]:
        keys = set(self._selected_option_keys_locked())
        keys.add(self.underlying_key)
        if self.futures_key:
            keys.add(self.futures_key)
        # Keep both index levels live so the AI can detect NIFTY/BANKNIFTY
        # divergence even though the option chain in this build is NIFTY.
        keys.update(self.index_level_keys.keys())
        keys.update(self.heavy_futures.keys())
        return {k for k in keys if k}

    def _ensure_streamer_subscriptions(self) -> None:
        if not self.enable_ws or not self.authenticated:
            return
        with self.lock:
            desired = self._desired_subscription_keys_locked()
            streamer = self.streamer
            connected = self.streamer_connected
            existing = set(self.subscribed_keys)

        if not streamer:
            self._start_streamer_thread()
            return
        if not connected:
            return

        add = sorted(desired - existing)
        remove = sorted(existing - desired)
        try:
            if remove:
                streamer.unsubscribe(remove)
            if add:
                streamer.subscribe(add, "full")
            with self.lock:
                self.subscribed_keys = desired
        except Exception as exc:
            with self.lock:
                self.streamer_error = f"subscription update: {exc}"

    def _start_streamer_thread(self) -> None:
        if self.ws_thread and self.ws_thread.is_alive():
            return

        def runner() -> None:
            try:
                import upstox_client  # type: ignore

                configuration = upstox_client.Configuration()
                configuration.access_token = self.access_token
                streamer = upstox_client.MarketDataStreamerV3(
                    upstox_client.ApiClient(configuration)
                )
                try:
                    streamer.auto_reconnect(True, 5, 20)
                except Exception:
                    pass

                def on_open() -> None:
                    with self.lock:
                        self.streamer_connected = True
                        self.streamer_error = ""
                        desired = self._desired_subscription_keys_locked()
                        self.subscribed_keys = desired
                    if desired:
                        streamer.subscribe(sorted(desired), "full")

                def on_message(message: Dict[str, Any]) -> None:
                    self._handle_stream_message(message)

                def on_error(error: Any) -> None:
                    with self.lock:
                        self.streamer_error = str(error)

                def on_close(*_args: Any) -> None:
                    with self.lock:
                        self.streamer_connected = False

                streamer.on("open", on_open)
                streamer.on("message", on_message)
                streamer.on("error", on_error)
                streamer.on("close", on_close)
                with self.lock:
                    self.streamer = streamer
                streamer.connect()
            except Exception as exc:
                with self.lock:
                    self.streamer_connected = False
                    self.streamer_error = f"WebSocket unavailable: {exc}"
                    self.streamer = None

        self.ws_thread = threading.Thread(target=runner, name="upstox-streamer", daemon=True)
        self.ws_thread.start()

    def _stop_streamer_locked(self) -> None:
        s = self.streamer
        self.streamer = None
        self.streamer_connected = False
        self.subscribed_keys.clear()
        if s:
            try:
                s.disconnect()
            except Exception:
                pass

    def _handle_stream_message(self, message: Dict[str, Any]) -> None:
        feeds = message.get("feeds") or {}
        ts_ms = safe_float(message.get("currentTs"), time.time() * 1000)
        ts = ts_ms / 1000 if ts_ms > 10_000_000_000 else time.time()
        with self.lock:
            self.last_message_ts = ts

        for key, raw in feeds.items():
            root = raw.get("firstLevelWithGreeks")
            if root is None:
                ff = raw.get("fullFeed") or raw.get("ff") or {}
                root = ff.get("marketFF") or ff.get("indexFF")
            if root is None:
                # LTPC mode has the payload directly under raw["ltpc"].
                root = raw.get("ltpc") or raw
            if not isinstance(root, dict):
                continue

            ltpc = root.get("ltpc") or {}
            if not ltpc and "ltp" in root:
                ltpc = root
            ltp = safe_float(ltpc.get("ltp"))
            cp = safe_float(ltpc.get("cp"))

            if key == self.underlying_key:
                with self.lock:
                    if ltp:
                        self.spot = ltp
                        self.index_levels["NIFTY"]["ltp"] = ltp
                    if cp:
                        self.spot_close = cp
                        self.index_levels["NIFTY"]["cp"] = cp
                continue

            if key in self.index_level_keys:
                code = self.index_level_keys[key]
                with self.lock:
                    if ltp:
                        self.index_levels[code]["ltp"] = ltp
                    if cp:
                        self.index_levels[code]["cp"] = cp
                continue

            if key == self.futures_key:
                with self.lock:
                    if ltp:
                        self.futures_ltp = ltp
                    atp = safe_float(root.get("atp"))
                    if atp:
                        self.futures_atp = atp
                    self._update_spot_vwap_from_future_locked()
                continue

            if key in self.heavy_futures:
                with self.lock:
                    h = self.heavy_futures[key]
                    if ltp:
                        h["ltp"] = ltp
                    if cp:
                        h["cp"] = cp
                continue

            with self.lock:
                loc = self.instrument_lookup.get(key)
            if not loc:
                continue
            strike, side = loc
            with self.lock:
                row = self.chain.get(strike)
                if not row:
                    continue
                depth = root.get("firstDepth") or {}
                if not depth:
                    quotes = ((root.get("marketLevel") or {}).get("bidAskQuote") or [])
                    depth = quotes[0] if quotes else {}
                greeks = root.get("optionGreeks") or {}
                vtt = safe_float(root.get("vtt"))
                oi_raw = safe_float(root.get("oi"))
                oi = oi_raw / 100000.0 if oi_raw else 0.0
                iv = safe_float(root.get("iv"))
                if iv and iv < 2:
                    iv *= 100
                prefix = "c" if side == "C" else "p"
                if ltp:
                    row[f"{prefix}ltp"] = ltp
                if vtt:
                    row[f"{prefix}vol"] = vtt
                if oi:
                    row[f"{prefix}oi"] = oi
                if iv:
                    row[f"{prefix}iv"] = iv
                if cp:
                    close_key = "call_close" if side == "C" else "put_close"
                    row[f"{prefix}p"] = pct_change(ltp, safe_float(row.get(close_key), cp))
                bidp = safe_float(depth.get("bidP") or depth.get("bid_price"))
                askp = safe_float(depth.get("askP") or depth.get("ask_price"))
                bidq = safe_float(depth.get("bidQ") or depth.get("bid_qty"))
                askq = safe_float(depth.get("askQ") or depth.get("ask_qty"))
                if bidp:
                    row[f"{prefix}bid"] = bidp
                if askp:
                    row[f"{prefix}ask"] = askp
                if bidq:
                    row[f"{prefix}bidq"] = bidq
                if askq:
                    row[f"{prefix}askq"] = askq
                for g in ("delta", "gamma", "theta", "vega"):
                    gv = safe_float(greeks.get(g))
                    if gv:
                        row[f"{prefix}_{g}"] = gv
                volume = safe_float(row.get(f"{prefix}vol"))
                oi_now = safe_float(row.get(f"{prefix}oi"))
                ltp_now = safe_float(row.get(f"{prefix}ltp"))
            self._record_history(key, volume, oi_now, ltp_now, ts=ts)

    def _update_spot_vwap_from_future_locked(self) -> None:
        # Futures ATP is a true exchange average traded price. Convert it into
        # a spot-equivalent reference by subtracting the current futures basis.
        if self.spot and self.futures_ltp and self.futures_atp:
            basis = self.futures_ltp - self.spot
            self.vwap = self.futures_atp - basis

    # ---------- microstructure history ----------
    def _record_history(
        self, key: str, volume: float, oi: float, ltp: float, ts: Optional[float] = None
    ) -> None:
        if not key:
            return
        ts = ts or time.time()
        dq = self.history[key]
        if dq and abs(dq[-1].ts - ts) < 0.35:
            dq[-1] = Tick(ts, volume, oi, ltp)
        else:
            dq.append(Tick(ts, volume, oi, ltp))
        cutoff = ts - 20 * 60
        while dq and dq[0].ts < cutoff:
            dq.popleft()

    def _sample_at_or_before(self, key: str, seconds_ago: float) -> Optional[Tick]:
        dq = self.history.get(key)
        if not dq:
            return None
        target = time.time() - seconds_ago
        candidate = None
        for tick in reversed(dq):
            if tick.ts <= target:
                return tick
            candidate = tick
        return candidate if candidate and candidate.ts < time.time() - 5 else None

    def _session_minutes(self) -> float:
        d = now_ist()
        minutes = (d.hour * 60 + d.minute + d.second / 60) - (9 * 60 + 15)
        return clamp(minutes, 1, 375)

    def _live_metrics(self, key: Optional[str], current_volume: float, current_oi: float, current_ltp: float) -> Dict[str, float]:
        if not key:
            return {"v1": 1.0, "v3": 1.0, "v5": 1.0, "oi_vel": 0.0, "prem": 0.0}
        session_avg = max(current_volume / self._session_minutes(), 1.0)

        def spike(sec: int, mins: int) -> float:
            old = self._sample_at_or_before(key, sec)
            if not old:
                return 1.0
            delta = max(0.0, current_volume - old.volume)
            return clamp((delta / max(mins, 1)) / session_avg, 0.0, 8.0)

        old1 = self._sample_at_or_before(key, 60)
        if old1:
            dt_min = max((time.time() - old1.ts) / 60.0, 0.1)
            # current_oi is already normalised to lakhs throughout the dashboard.
            oi_vel = (current_oi - old1.oi) / dt_min
            prem = (current_ltp - old1.ltp) / dt_min
        else:
            oi_vel = 0.0
            prem = 0.0
        return {
            "v1": spike(60, 1),
            "v3": spike(180, 3),
            "v5": spike(300, 5),
            "oi_vel": clamp(oi_vel, -99, 99),
            "prem": clamp(prem, -999, 999),
        }

    # ---------- analytics ----------
    def sync_analytics(self) -> None:
        if not self.authenticated or not self.current_expiry:
            return
        today = now_ist().date().isoformat()
        max_pain = None
        pcr = None
        note_parts = []
        try:
            mp = self.get(
                f"{BASE_V2}/market/max-pain",
                params={
                    "instrument_key": self.underlying_key,
                    "expiry": self.current_expiry,
                    "date": today,
                    "bucket_interval": 60,
                },
            )
            d = mp.get("data") or {}
            max_pain = safe_float(d.get("max_pain")) or None
        except Exception as exc:
            note_parts.append(f"max-pain unavailable: {exc}")
        try:
            pr = self.get(
                f"{BASE_V2}/market/pcr",
                params={
                    "instrument_key": self.underlying_key,
                    "expiry": self.current_expiry,
                    "date": today,
                    "bucket_interval": 60,
                },
            )
            d = pr.get("data") or {}
            pcr = safe_float(d.get("pcr")) or None
        except Exception as exc:
            note_parts.append(f"PCR unavailable: {exc}")
        series: Dict[int, List[float]] = {}
        for interval in (3, 5, 15):
            try:
                encoded_key = quote(self.underlying_key, safe="")
                r = self.get(
                    f"{BASE_V3}/historical-candle/intraday/{encoded_key}/minutes/{interval}"
                )
                candles = ((r.get("data") or {}).get("candles") or [])
                closes = []
                for c in reversed(candles):
                    if isinstance(c, (list, tuple)) and len(c) >= 5:
                        closes.append(safe_float(c[4]))
                closes = [x for x in closes if x > 0][-40:]
                if closes:
                    series[interval] = closes
            except Exception as exc:
                note_parts.append(f"{interval}m candles unavailable")
        with self.lock:
            if max_pain is not None:
                self.official_max_pain = max_pain
            if pcr is not None:
                self.official_pcr = pcr
            for k, v in series.items():
                self.price_series[k] = v
            self.analytics_note = "; ".join(note_parts[:3])
            self.last_analytics_sync = time.time()

    # ---------- background lifecycle ----------
    def start_background(self) -> None:
        if self.bg_thread and self.bg_thread.is_alive():
            return
        self.stop_event.clear()

        def loop() -> None:
            while not self.stop_event.is_set():
                if not self.authenticated:
                    time.sleep(1)
                    continue
                try:
                    if not self.current_expiry:
                        exps = self.fetch_expiries()
                        if exps:
                            self.current_expiry = exps[0]
                    if not self.chain or time.time() - self.last_rest_sync >= self.rest_sync_seconds:
                        self.sync_chain_rest()
                    if time.time() - self.last_analytics_sync >= self.analytics_sync_seconds:
                        self.sync_analytics()
                    if self.enable_ws:
                        self._ensure_streamer_subscriptions()
                    # REST fallback becomes more frequent when WS is not connected.
                    sleep_for = 1.0 if self.streamer_connected else 3.0
                except Exception as exc:
                    with self.lock:
                        self.streamer_error = str(exc)
                    sleep_for = 3.0
                self.stop_event.wait(sleep_for)

        self.bg_thread = threading.Thread(target=loop, name="upstox-sync", daemon=True)
        self.bg_thread.start()

    def stop(self) -> None:
        self.stop_event.set()
        with self.lock:
            self._stop_streamer_locked()
        try:
            self.client.close()
        except Exception:
            pass

    # ---------- diagnostics ----------
    def diagnostics(self) -> Dict[str, Any]:
        """Run read-only checks against Upstox and return actionable status.

        No orders are placed and the access token is never returned to the browser.
        """
        checks: List[Dict[str, Any]] = []
        if not self.authenticated:
            return {
                "ok": False,
                "checks": [{"name": "authentication", "ok": False, "detail": "No Upstox token connected"}],
            }

        try:
            exps = self.fetch_expiries(force=True)
            checks.append({"name": "option_contracts", "ok": bool(exps), "detail": f"{len(exps)} expiries discovered"})
        except Exception as exc:
            checks.append({"name": "option_contracts", "ok": False, "detail": str(exc)})
            return {"ok": False, "checks": checks}

        try:
            self.sync_chain_rest(self.current_expiry or (exps[0] if exps else None))
            checks.append({"name": "option_chain", "ok": bool(self.chain), "detail": f"{len(self.chain)} strikes loaded"})
        except Exception as exc:
            checks.append({"name": "option_chain", "ok": False, "detail": str(exc)})

        try:
            encoded_key = quote(self.underlying_key, safe="")
            r = self.get(f"{BASE_V3}/historical-candle/intraday/{encoded_key}/minutes/5")
            candles = ((r.get("data") or {}).get("candles") or [])
            checks.append({"name": "intraday_candles", "ok": isinstance(candles, list), "detail": f"{len(candles)} candles returned"})
        except Exception as exc:
            checks.append({"name": "intraday_candles", "ok": False, "detail": str(exc)})

        # WebSocket may be silent outside market hours. Report connection state separately
        # instead of treating a closed market as a hard failure.
        checks.append({
            "name": "websocket_v3",
            "ok": bool(self.streamer_connected),
            "detail": "connected" if self.streamer_connected else (self.streamer_error or "starting / market may be closed"),
        })
        hard = [c for c in checks if c["name"] != "websocket_v3"]
        return {"ok": all(c["ok"] for c in hard), "checks": checks, "status": self.status()}

    # ---------- dashboard view ----------
    def _pitch_snapshot_locked(self) -> List[Dict[str, Any]]:
        """Legacy NIFTY weighted-breadth rows consumed by the fusion engine."""
        rows: List[Dict[str, Any]] = []
        by_query = {v.get("query"): v for v in self.heavy_futures.values()}
        for spec in INDEX_UNIVERSES["NIFTY"]["stocks"]:
            query = spec["symbol"]
            h = by_query.get(query, {})
            ltp = safe_float(h.get("ltp"))
            cp = safe_float(h.get("cp"))
            rows.append({
                "n": spec["name"],
                "symbol": query,
                "cmp": ltp,
                "f": pct_change(ltp, cp) if ltp and cp else 0.0,
                "w": safe_float(spec.get("weight")),
                "live": bool(ltp and cp),
            })
        return rows

    def _index_brain_snapshot_locked(self) -> Dict[str, Any]:
        runtime_by_symbol = {
            str(v.get("query")): {
                "ltp": safe_float(v.get("ltp")),
                "cp": safe_float(v.get("cp")),
                "instrument_key": v.get("instrument_key"),
            }
            for v in self.heavy_futures.values()
            if v.get("query")
        }
        levels = {k: dict(v) for k, v in self.index_levels.items()}
        return analyse_index_brains(runtime_by_symbol, levels)

    def snapshot(self) -> Dict[str, Any]:
        with self.lock:
            rows = [dict(r) for _, r in sorted(self.chain.items())]
            spot = self.spot
            expiry = self.current_expiry
            official_max_pain = self.official_max_pain
            official_pcr = self.official_pcr
            vwap = self.vwap
            price_series = {str(k): list(v) for k, v in self.price_series.items()}
            pitch = self._pitch_snapshot_locked()
            index_brain = self._index_brain_snapshot_locked()
            ws_connected = self.streamer_connected
            ws_error = self.streamer_error
            last_msg = self.last_message_ts
            iv_proxy = self.iv_proxy

        if rows and spot:
            rows.sort(key=lambda r: abs(r["s"] - spot))
            # Keep a wide but manageable UI window around ATM.
            rows = rows[: max(9, self.strike_window * 2 + 5)]
            rows.sort(key=lambda r: r["s"])

        out: List[Dict[str, Any]] = []
        for r in rows:
            cm = self._live_metrics(r.get("call_key"), r["cvol"], r["coi"], r["cltp"])
            pm = self._live_metrics(r.get("put_key"), r["pvol"], r["poi"], r["pltp"])
            row = {
                "s": r["s"],
                "coi": r["coi"],
                "cchg": r["cchg"],
                "cvol": r["cvol"],
                "cltp": r["cltp"],
                "cp": r["cp"],
                "civ": r["civ"],
                "poi": r["poi"],
                "pchg": r["pchg"],
                "pvol": r["pvol"],
                "pltp": r["pltp"],
                "pp": r["pp"],
                "piv": r["piv"],
                "cbid": r["cbid"],
                "cask": r["cask"],
                "cbidq": r["cbidq"],
                "caskq": r["caskq"],
                "cv1": cm["v1"],
                "cv3": cm["v3"],
                "cv5": cm["v5"],
                "coivel": cm["oi_vel"],
                "cprem": cm["prem"],
                "pbid": r["pbid"],
                "pask": r["pask"],
                "pbidq": r["pbidq"],
                "paskq": r["paskq"],
                "pv1": pm["v1"],
                "pv3": pm["v3"],
                "pv5": pm["v5"],
                "poivel": pm["oi_vel"],
                "pprem": pm["prem"],
                # Real greeks from Upstox. UI uses these when present.
                "c_delta": r.get("c_delta", 0),
                "c_gamma": r.get("c_gamma", 0),
                "c_theta": r.get("c_theta", 0),
                "c_vega": r.get("c_vega", 0),
                "p_delta": r.get("p_delta", 0),
                "p_gamma": r.get("p_gamma", 0),
                "p_theta": r.get("p_theta", 0),
                "p_vega": r.get("p_vega", 0),
                "call_key": r.get("call_key"),
                "put_key": r.get("put_key"),
            }
            out.append(row)

        # If futures-derived VWAP isn't ready yet, use a conservative session-price
        # reference rather than inventing a true VWAP.
        if not vwap:
            series = price_series.get("5") or price_series.get("3") or []
            vwap = statistics.mean(series[-12:]) if series else spot

        return {
            "ok": True,
            "source": "upstox_websocket_v3" if ws_connected else "upstox_rest_fallback",
            "spot": spot,
            "vwap": vwap,
            "vwap_source": "NIFTY futures ATP adjusted for current basis"
            if self.futures_atp and self.futures_ltp
            else "intraday price-reference fallback",
            "expiry": expiry,
            "option_data": out,
            "price_series": price_series,
            "official_max_pain": official_max_pain,
            "official_pcr": official_pcr,
            "iv_proxy": iv_proxy,
            "pitch": pitch,
            "index_brain": index_brain,
            "websocket_connected": ws_connected,
            "websocket_error": ws_error,
            "last_tick_epoch": last_msg,
            "server_time": datetime.now(timezone.utc).isoformat(),
            "analytics_note": self.analytics_note,
        }

    def status(self) -> Dict[str, Any]:
        with self.lock:
            return {
                "authenticated": self.authenticated,
                "configured_app": self.configured_app,
                "token_source": self.token_source,
                "underlying": self.underlying_key,
                "current_expiry": self.current_expiry,
                "chain_rows": len(self.chain),
                "websocket_enabled": self.enable_ws,
                "websocket_connected": self.streamer_connected,
                "websocket_error": self.streamer_error,
                "last_tick_epoch": self.last_message_ts,
                "breadth_live_contracts": sum(
                    1 for x in self.heavy_futures.values() if x.get("ltp") and x.get("cp")
                ),
                "token_hint": "Standard OAuth tokens expire at 3:30 AM the following day; Upstox Analytics Tokens are read-only and can be valid for 1 year.",
            }

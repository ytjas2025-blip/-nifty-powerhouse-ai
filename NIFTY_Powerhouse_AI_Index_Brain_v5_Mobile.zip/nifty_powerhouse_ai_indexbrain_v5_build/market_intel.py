from __future__ import annotations
from datetime import date, datetime
from math import isfinite


def _n(v, d=0.0):
    try:
        x=float(v); return x if isfinite(x) else d
    except Exception: return d

def _ok(v):
    try: return v is not None and isfinite(float(v))
    except Exception: return False

def _clamp(v,a=0.0,b=100.0): return max(a,min(b,v))

def _series_slope(values):
    vals=[_n(x) for x in (values or []) if x is not None]
    if len(vals)<2 or vals[0]==0: return None
    return (vals[-1]-vals[0])/abs(vals[0])*100

def _dir_label(x, flat=.035):
    if x is None:return 'N/A'
    return 'UP' if x>flat else 'DOWN' if x<-flat else 'FLAT'

def _iv_regime(iv):
    if iv is None:return 'N/A'
    v=_n(iv); return 'VERY HIGH' if v>=30 else 'HIGH' if v>=22 else 'NORMAL' if v>=15 else 'LOW'

def _expiry_days(expiry):
    if not expiry or str(expiry).upper()=='DEMO': return None
    raw=str(expiry)[:10]
    try:return (datetime.fromisoformat(raw).date()-date.today()).days
    except Exception:return None

def _expiry_mode(days):
    if days is None:return 'N/A'
    if days<0:return 'EXPIRED'
    if days==0:return 'EXPIRY DAY'
    if days==1:return 'T-1 EXPIRY'
    if days<=3:return 'NEAR EXPIRY'
    return 'NORMAL EXPIRY'

def _greek_intel(rows,spot):
    if not rows:return {'available':False,'coverage_pct':0.0,'gamma_pressure':'N/A','theta_pressure':'N/A','delta_balance':None}
    near=sorted(rows,key=lambda r:abs(_n(r.get('s'))-spot))[:7] if spot else rows[:7]
    valid=[r for r in near if _ok(r.get('c_delta')) and _ok(r.get('p_delta'))]
    cov=len(valid)/max(len(near),1)*100
    if not valid:return {'available':False,'coverage_pct':round(cov,1),'gamma_pressure':'N/A','theta_pressure':'N/A','delta_balance':None}
    gamma=sum(abs(_n(r.get('c_gamma')))+abs(_n(r.get('p_gamma'))) for r in valid)
    theta=sum(abs(_n(r.get('c_theta')))+abs(_n(r.get('p_theta'))) for r in valid)
    bal=sum(_n(r.get('c_delta'))+_n(r.get('p_delta')) for r in valid)/len(valid)
    gamma_state='ELEVATED' if gamma>0.035 else 'MODERATE' if gamma>0.015 else 'LOW'
    theta_state='HEAVY' if theta>70 else 'MODERATE' if theta>35 else 'LIGHT'
    return {'available':True,'coverage_pct':round(cov,1),'gamma_pressure':gamma_state,'gamma_sum':round(gamma,5),'theta_pressure':theta_state,'theta_sum':round(theta,2),'delta_balance':round(bal,3)}

def _premium_divergence(rows,spot,trend):
    if not rows or trend is None:return {'available':False,'state':'N/A'}
    near=sorted(rows,key=lambda r:abs(_n(r.get('s'))-spot))[:3]
    cps=[_n(r.get('cp')) for r in near if _ok(r.get('cp'))]
    pps=[_n(r.get('pp')) for r in near if _ok(r.get('pp'))]
    if not cps or not pps:return {'available':False,'state':'N/A'}
    ce=sum(cps)/len(cps); pe=sum(pps)/len(pps)
    state='CONFIRMED'
    if trend>.035 and ce<=0: state='BULLISH PRICE / CE PREMIUM DIVERGENCE'
    elif trend<-.035 and pe<=0: state='BEARISH PRICE / PE PREMIUM DIVERGENCE'
    elif trend>.035 and pe>ce: state='PUT PREMIUM RESILIENCE'
    elif trend<-.035 and ce>pe: state='CALL PREMIUM RESILIENCE'
    return {'available':True,'state':state,'ce_change_pct':round(ce,3),'pe_change_pct':round(pe,3)}

def analyse_market_intel(snapshot:dict, ai:dict|None=None, smart:dict|None=None)->dict:
    ai=ai or {}; smart=smart or {}; spot=_n(snapshot.get('spot')); vwap=_n(snapshot.get('vwap'))
    ps=snapshot.get('price_series') or {}; slopes={k:_series_slope(ps.get(k)) for k in ('3','5','15')}; labels={k:_dir_label(v) for k,v in slopes.items()}
    votes=[]
    for k,w in [('3',1.0),('5',1.2),('15',1.5)]:
        s=slopes[k]
        if s is not None:votes.append((1 if s>.035 else -1 if s<-.035 else 0,w))
    mtf=sum(v*w for v,w in votes)/sum(w for _,w in votes) if votes else 0; mtf_score=_clamp(50+mtf*42)
    mtf_label='BULLISH ALIGNMENT' if mtf_score>=65 else 'BEARISH ALIGNMENT' if mtf_score<=35 else 'MIXED / RANGE'
    vwap_dist=((spot-vwap)/vwap*100) if spot and vwap else None; vwap_state='ABOVE VWAP' if vwap_dist is not None and vwap_dist>.03 else 'BELOW VWAP' if vwap_dist is not None and vwap_dist<-.03 else 'AT VWAP'
    mp=snapshot.get('official_max_pain'); mp=_n(mp) if mp is not None else None; mp_dist=((spot-mp)/spot*100) if mp and spot else None
    pcr=snapshot.get('official_pcr'); pcr=_n(pcr) if pcr is not None else None; pcr_state='N/A' if pcr is None else 'PUT-HEAVY' if pcr>=1.25 else 'CALL-HEAVY' if pcr<=.80 else 'BALANCED'
    iv=snapshot.get('iv_proxy'); iv=_n(iv) if iv is not None else None
    cw=smart.get('call_wall'); pw=smart.get('put_wall'); wall_state='N/A'; wall_width=None
    if cw is not None and pw is not None and spot:
        cw=_n(cw);pw=_n(pw);wall_width=abs(cw-pw);wall_state='BETWEEN WALLS' if pw<spot<cw else 'ABOVE CALL WALL' if spot>=cw else 'BELOW PUT WALL'
    # Opening range / session geometry
    sc=snapshot.get('session_context') or {}; orh=sc.get('opening_range_high'); orl=sc.get('opening_range_low'); dh=sc.get('day_high'); dl=sc.get('day_low'); dop=sc.get('day_open')
    opening_state='N/A'; or_dist=None
    if _ok(orh) and _ok(orl) and spot:
        orh=_n(orh);orl=_n(orl);width=max(orh-orl,1e-9)
        opening_state='ABOVE OR HIGH' if spot>orh else 'BELOW OR LOW' if spot<orl else 'INSIDE OPENING RANGE'
        or_dist=(spot-(orh if spot>=orh else orl if spot<=orl else (orh+orl)/2))/spot*100
    # Expiry brain
    ed=_expiry_days(snapshot.get('expiry')); em=_expiry_mode(ed); pin=None
    if mp and spot: pin=abs(spot-mp)/spot*100
    expiry_risk=0
    if ed is not None: expiry_risk += 45 if ed==0 else 28 if ed==1 else 12 if ed<=3 else 0
    if pin is not None: expiry_risk += max(0,35-min(35,pin*120))
    if iv is not None and iv>=25: expiry_risk+=12
    expiry_risk=_clamp(expiry_risk)
    rows=snapshot.get('option_data') or []; greek=_greek_intel(rows,spot); prem=_premium_divergence(rows,spot,slopes.get('5'))
    active=str(snapshot.get('active_underlying') or 'NIFTY').upper(); brain=((snapshot.get('index_brain') or {}).get(active) or {})
    sectors=brain.get('sectors') or []; sector_bulls=sum(1 for x in sectors if x.get('state')=='BULL'); sector_bears=sum(1 for x in sectors if x.get('state')=='BEAR')
    sector_state='N/A' if not sectors else 'BROAD BULL LEADERSHIP' if sector_bulls>=max(2,sector_bears*1.5) else 'BROAD BEAR LEADERSHIP' if sector_bears>=max(2,sector_bulls*1.5) else 'ROTATION / MIXED'
    ai_side=str(ai.get('side') or 'WAIT').upper(); flow=str(smart.get('direction') or 'INSUFFICIENT DATA'); quality=_n(smart.get('data_quality'));trap=_n(smart.get('trap_risk'));ai_conf=_n(ai.get('confidence'))
    directional=0
    if ai_side=='CE':directional+=1
    elif ai_side=='PE':directional-=1
    if flow=='BULLISH FOOTPRINT':directional+=1
    elif flow=='BEARISH FOOTPRINT':directional-=1
    if mtf_score>=65:directional+=1
    elif mtf_score<=35:directional-=1
    if vwap_dist is not None:directional+=.5 if vwap_dist>.03 else -.5 if vwap_dist<-.03 else 0
    if opening_state=='ABOVE OR HIGH':directional+=.5
    elif opening_state=='BELOW OR LOW':directional-=.5
    if sector_state=='BROAD BULL LEADERSHIP':directional+=.5
    elif sector_state=='BROAD BEAR LEADERSHIP':directional-=.5
    alignment=abs(directional)/4.5*100; confluence=_clamp(.30*ai_conf+.24*quality+.25*alignment+.13*(100-trap)+.08*(100-expiry_risk))
    risk_flags=[]
    if quality<55:risk_flags.append('LOW DATA QUALITY')
    if trap>=65:risk_flags.append('HIGH TRAP RISK')
    if expiry_risk>=65:risk_flags.append('EXPIRY / PIN RISK')
    if flow=='INSUFFICIENT DATA':risk_flags.append('FLOW DATA INSUFFICIENT')
    if ai_side=='CE' and flow=='BEARISH FOOTPRINT' or ai_side=='PE' and flow=='BULLISH FOOTPRINT':risk_flags.append('AI / FLOW CONFLICT')
    if prem.get('available') and prem.get('state')!='CONFIRMED':risk_flags.append('PREMIUM DIVERGENCE')
    if labels.get('3')!='N/A' and labels.get('15')!='N/A' and labels['3']!=labels['15'] and 'FLAT' not in (labels['3'],labels['15']):risk_flags.append('SHORT/LONG HORIZON DIVERGENCE')
    gates={'data_quality':quality>=55,'trap':trap<65,'flow':flow!='INSUFFICIENT DATA','mtf':mtf_score>=60 or mtf_score<=40,'premium':not prem.get('available') or prem.get('state')=='CONFIRMED','expiry':expiry_risk<75}
    gates_passed=sum(gates.values()); gates_total=len(gates)
    if quality<55:desk_verdict='DATA GATE / WAIT'
    elif trap>=75 or expiry_risk>=85:desk_verdict='RISK GATE / WAIT'
    elif abs(directional)<1.75:desk_verdict='MIXED / WAIT'
    else:desk_verdict='BULLISH CONFLUENCE' if directional>0 else 'BEARISH CONFLUENCE'
    return {
      'engine':'Pro Desk Intelligence v12','active_underlying':active,'desk_verdict':desk_verdict,'confluence_score':round(confluence,1),'decision_stack':{'gates':gates,'passed':gates_passed,'total':gates_total,'directional_score':round(directional,2)},
      'multi_timeframe':{'score':round(mtf_score,1),'label':mtf_label,'slopes_pct':{k:(round(v,3) if v is not None else None) for k,v in slopes.items()},'labels':labels},
      'vwap':{'state':vwap_state,'distance_pct':round(vwap_dist,3) if vwap_dist is not None else None,'value':vwap or None},
      'opening_range':{'state':opening_state,'high':orh if _ok(orh) else None,'low':orl if _ok(orl) else None,'day_open':_n(dop) if _ok(dop) else None,'day_high':_n(dh) if _ok(dh) else None,'day_low':_n(dl) if _ok(dl) else None,'distance_pct':round(or_dist,3) if or_dist is not None else None},
      'max_pain':{'value':mp,'distance_pct':round(mp_dist,3) if mp_dist is not None else None},'pcr':{'value':pcr,'state':pcr_state},'iv':{'value':iv,'regime':_iv_regime(iv)},
      'expiry_brain':{'days_to_expiry':ed,'mode':em,'pin_distance_pct':round(pin,3) if pin is not None else None,'risk_score':round(expiry_risk,1)},
      'greeks_brain':greek,'premium_divergence':prem,'sector_rotation':{'state':sector_state,'bull_sectors':sector_bulls,'bear_sectors':sector_bears,'leaders':sectors[:5]},
      'walls':{'state':wall_state,'call_wall':cw if cw is not None else None,'put_wall':pw if pw is not None else None,'width':wall_width},'risk_flags':risk_flags,
      'note':'Confluence measures agreement/quality of observed inputs; it is not probability of profit and does not execute orders.'}

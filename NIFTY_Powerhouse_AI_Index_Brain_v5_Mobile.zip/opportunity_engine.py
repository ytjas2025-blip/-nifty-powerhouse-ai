from __future__ import annotations
from typing import Any, Dict, List, Optional
import math
import time


def num(v: Any) -> Optional[float]:
    try:
        if v is None or v == "":
            return None
        x = float(v)
        return x if math.isfinite(x) else None
    except Exception:
        return None


def clamp(x: float, lo: float = 0.0, hi: float = 100.0) -> float:
    return max(lo, min(hi, x))


def grade(q: float) -> str:
    return "A+" if q >= 88 else "A" if q >= 80 else "B+" if q >= 70 else "B" if q >= 60 else "WATCH"


def lifecycle(q: float, live: bool = True, reward_ok: bool = True) -> str:
    if not live:
        return "DATA WAIT"
    if not reward_ok:
        return "FILTERED — SMALL MOVE"
    if q >= 88:
        return "TRIGGER READY"
    if q >= 82:
        return "READY"
    if q >= 70:
        return "ARMING"
    if q >= 60:
        return "BUILDING"
    return "WATCH"


def scenario_levels(spot: Optional[float], chg: float, action: str) -> Dict[str, Any]:
    if not spot:
        return {"entry_trigger": None, "sl": None, "t1": None, "t2": None, "note": "Spot unavailable"}
    direction = 1 if action in ("BUY", "CE") else -1
    risk_pct = clamp(0.40 + abs(chg) * 0.11, 0.40, 0.95)
    trigger_pct = clamp(0.10 + abs(chg) * 0.03, 0.10, 0.24)
    entry = spot * (1 + direction * trigger_pct / 100)
    sl = entry * (1 - direction * risk_pct / 100)
    t1 = entry * (1 + direction * (risk_pct * 2.0) / 100)
    t2 = entry * (1 + direction * (risk_pct * 3.2) / 100)
    return {
        "entry_trigger": round(entry, 2),
        "sl": round(sl, 2),
        "t1": round(t1, 2),
        "t2": round(t2, 2),
        "risk_pct": round(risk_pct, 2),
        "note": "Analytical scenario levels; require live trigger acceptance. No execution.",
    }


def _market_state(bull: int, bear: int, moves: List[float]) -> str:
    n = bull + bear
    if not n:
        return "DATA WAIT"
    breadth = (bull - bear) / n
    avg = sum(abs(x) for x in moves) / max(1, len(moves))
    if abs(breadth) < .18 and avg < .55:
        return "COMPRESSION / RANGE"
    if breadth > .42:
        return "TRENDING UP"
    if breadth < -.42:
        return "TRENDING DOWN"
    if avg > 1.25:
        return "VOLATILE / EXPANSION"
    return "MIXED / ROTATION"


def _maturity(q: float, move: float) -> str:
    a = abs(move)
    if q < 60:
        return "WATCH"
    if q < 70:
        return "FORMING"
    if a > 3.25:
        return "LATE / CHASE RISK"
    if q >= 88:
        return "MATURE"
    return "FRESH / ACTIVE"


def _flip(action: str) -> str:
    if action == "BUY":
        return "Bull thesis invalidates if trigger/VWAP structure fails and sector/volume confirmation turns negative."
    if action == "SELL":
        return "Bear thesis invalidates if price reclaims trigger/VWAP structure with positive sector/volume confirmation."
    if action == "CE":
        return "CE thesis invalidates if index structure and option-flow confirmation turn bearish."
    return "PE thesis invalidates if index structure and option-flow confirmation turn bullish."


def _news_signal(news: List[Dict[str, Any]]) -> Dict[str, Any]:
    tones = [str(x.get("tone") or "") for x in news[:4]]
    if any("NEGATIVE" in x for x in tones):
        return {"label": "NEGATIVE CATALYST", "score": -7}
    if any("POSITIVE" in x for x in tones):
        return {"label": "POSITIVE CATALYST", "score": 7}
    if any("EVENT RISK" in x for x in tones):
        return {"label": "EVENT RISK", "score": -2}
    return {"label": "NO MATERIAL CATALYST" if not news else "NEUTRAL NEWS", "score": 0}


def _year_context(ltp: float, high: Optional[float], low: Optional[float], action: str) -> Dict[str, Any]:
    out = {"label": "52W N/A", "score": 0.0, "distance_pct": None, "breakout": False}
    if action == "BUY" and high and high > 0:
        d = (ltp / high - 1) * 100
        out["distance_pct"] = round(d, 2)
        if d >= 0:
            out.update(label="52W HIGH BREAK", score=13.0, breakout=True)
        elif d >= -1.0:
            out.update(label="NEAR 52W HIGH", score=7.0)
    elif action == "SELL" and low and low > 0:
        d = (ltp / low - 1) * 100
        out["distance_pct"] = round(d, 2)
        if d <= 0:
            out.update(label="52W LOW BREAK", score=13.0, breakout=True)
        elif d <= 1.0:
            out.update(label="NEAR 52W LOW", score=7.0)
    return out


def _volume_context(row: Dict[str, Any], median_delta: Optional[float]) -> Dict[str, Any]:
    vd = num(row.get("volume_delta"))
    vol = num(row.get("volume"))
    if vd is None:
        return {"label": "VOLUME ACCEL N/A", "score": 0.0, "volume": vol, "delta": None, "confirmed": False}
    if median_delta and median_delta > 0:
        ratio = vd / median_delta
        if ratio >= 3.0:
            return {"label": f"VOLUME ACCEL {ratio:.1f}×", "score": 15.0, "volume": vol, "delta": vd, "confirmed": True}
        if ratio >= 1.5:
            return {"label": f"VOLUME ACCEL {ratio:.1f}×", "score": 9.0, "volume": vol, "delta": vd, "confirmed": True}
    return {"label": "VOLUME NORMAL", "score": 1.0, "volume": vol, "delta": vd, "confirmed": False}


def _reward_floor(levels: Dict[str, Any], kind: str) -> Dict[str, Any]:
    e, t1 = num(levels.get("entry_trigger")), num(levels.get("t1"))
    if e is None or t1 is None:
        return {"ok": False, "points": None, "reason": "target unavailable"}
    pts = abs(t1 - e)
    # User preference: suppress tiny 1–2 point equity trades.
    min_pts = 2.0 if kind == "STOCK" else 0.0
    return {"ok": pts >= min_pts, "points": round(pts, 2), "minimum_points": min_pts,
            "reason": None if pts >= min_pts else f"T1 distance {pts:.2f} < {min_pts:.2f} point floor"}


def _index_option_contract(market: Dict[str, Any], ai: Dict[str, Any], side: str) -> Optional[Dict[str, Any]]:
    tc = ai.get("top_contract") or {}
    strike = num(tc.get("strike"))
    if strike:
        return {"strike": strike, "side": side, "expiry": market.get("expiry"), "source": "AI ranked index contract"}
    spot = num(market.get("spot"))
    rows = market.get("option_data") or []
    if not spot or not rows:
        return None
    def strike_of(r: Dict[str, Any]) -> Optional[float]:
        return num(r.get("s") if r.get("s") is not None else r.get("strike"))
    usable = [(abs((strike_of(r) or 1e18) - spot), r) for r in rows if strike_of(r) is not None]
    if not usable:
        return None
    r = min(usable, key=lambda z: z[0])[1]
    st = strike_of(r)
    premium = num(r.get("cltp" if side == "CE" else "pltp"))
    return {"strike": st, "side": side, "expiry": market.get("expiry"), "premium_ltp": premium, "source": "nearest liquid-visible index strike"}


def build_opportunity_radar(market: Dict[str, Any], ai: Dict[str, Any], smart_money: Dict[str, Any]) -> Dict[str, Any]:
    raw = market.get("sector_heatmap") or []
    rows = [x for x in raw if x and x.get("live") and num(x.get("change_pct")) is not None and num(x.get("ltp")) is not None]
    groups: Dict[str, List[Dict[str, Any]]] = {}
    for r in rows:
        groups.setdefault(r.get("sector") or "Other", []).append(r)
    sector_avg = {k: sum(num(x.get("change_pct")) or 0 for x in v) / max(1, len(v)) for k, v in groups.items()}
    deltas = sorted([num(x.get("volume_delta")) for x in rows if num(x.get("volume_delta")) is not None and (num(x.get("volume_delta")) or 0) > 0])
    median_delta = deltas[len(deltas)//2] if deltas else None
    bull = sum((num(x.get("change_pct")) or 0) > 0 for x in rows)
    bear = sum((num(x.get("change_pct")) or 0) < 0 for x in rows)
    breadth_ratio = (bull - bear) / max(1, len(rows))
    candidates: List[Dict[str, Any]] = []

    for r in rows:
        chg = num(r.get("change_pct")) or 0.0
        if abs(chg) < 0.18:
            continue
        action = "BUY" if chg > 0 else "SELL"
        sec = r.get("sector") or "Other"
        sa = sector_avg.get(sec, 0.0)
        aligned = (chg > 0 and sa > 0) or (chg < 0 and sa < 0)
        ltp = num(r.get("ltp"))
        if not ltp:
            continue
        yc = _year_context(ltp, num(r.get("year_high")), num(r.get("year_low")), action)
        vc = _volume_context(r, median_delta)
        ns = _news_signal(r.get("news") or [])
        momentum = clamp(abs(chg) * 22, 0, 40)
        score = 34 + momentum + (14 if aligned else 2) + clamp(abs(sa) * 7, 0, 10) + yc["score"] + vc["score"] + ns["score"]
        q = clamp(score, 0, 97)
        levels = scenario_levels(ltp, chg, action)
        reward = _reward_floor(levels, "STOCK")
        life = lifecycle(q, True, reward["ok"])
        reasons = [f"{chg:+.2f}% live move", f"{sec} {sa:+.2f}%"]
        reasons.append("sector confirmation" if aligned else "sector divergence")
        if abs(chg) >= 1.0:
            reasons.append("momentum expansion")
        if yc["label"] != "52W N/A":
            reasons.append(yc["label"])
        if vc["confirmed"]:
            reasons.append(vc["label"])
        if ns["label"] not in ("NO MATERIAL CATALYST", "NEUTRAL NEWS"):
            reasons.append(ns["label"])
        conflicts = [] if aligned else ["sector not confirming stock direction"]
        if not reward["ok"]:
            conflicts.append(reward["reason"])
        if ns["label"] == "NEGATIVE CATALYST" and action == "BUY":
            conflicts.append("negative news conflicts with buy thesis")
        if ns["label"] == "POSITIVE CATALYST" and action == "SELL":
            conflicts.append("positive news conflicts with sell thesis")
        candidates.append({
            "symbol": r.get("symbol"), "kind": "STOCK", "instrument_type": "CASH",
            "sector": sec, "ltp": ltp, "change_pct": round(chg, 2), "side": action, "action": action,
            "quality": round(q), "grade": grade(q), "lifecycle": life, "maturity": _maturity(q, chg),
            "chase_risk": "HIGH" if abs(chg) > 3.25 else "MEDIUM" if abs(chg) > 2.1 else "LOW",
            "conflict": 0 if aligned else 35, "reasons": reasons[:7], "counter_signals": conflicts,
            "flip_condition": _flip(action), "option_preference": None, "levels": levels,
            "reward_filter": reward, "year_context": yc, "volume_context": vc,
            "news_context": {"label": ns["label"], "headlines": (r.get("news") or [])[:3]},
            "smart_money_proxy": {
                "label": "LARGE ACTIVITY PROXY" if vc["confirmed"] and aligned else "PARTICIPATION WATCH",
                "volume_acceleration": vc["label"], "sector_confirmation": aligned,
                "identity_claim": False,
            },
            "data_trust": 100 if r.get("quote_ts") else 78,
            "freshness": "LIVE", "instrument_key": r.get("instrument_key"), "isin": r.get("isin"),
            "decision_rule": "one active cash thesis per stock; no simultaneous CE/PE stock alerts",
        })

    # Index options remain options and MUST include a concrete strike when available.
    code = market.get("active_underlying") or "NIFTY"
    spot = num(market.get("spot"))
    ai_side = ai.get("side") or "WAIT"
    if ai_side in ("CE", "PE"):
        aq = clamp(num(ai.get("confidence")) or 0)
        dq = clamp(num(ai.get("data_quality")) or 90)
        contract = _index_option_contract(market, ai, ai_side)
        candidates.append({
            "symbol": code, "kind": "INDEX", "instrument_type": "OPTION", "ltp": spot, "change_pct": None,
            "side": ai_side, "action": "BUY_OPTION", "quality": round(aq), "grade": grade(aq),
            "lifecycle": lifecycle(aq, bool(spot), True), "maturity": "MATURE" if aq >= 88 else "FRESH / ACTIVE" if aq >= 70 else "FORMING",
            "chase_risk": "LOW", "conflict": round(clamp(100 - (num(ai.get("stability")) or 70))),
            "reasons": [str(x) for x in (ai.get("reasons") or [])[:4]] or ["multi-agent index confluence"],
            "counter_signals": [str(x) for x in (ai.get("risk_flags") or [])[:3]], "flip_condition": _flip(ai_side),
            "option_contract": contract, "option_preference": f"{ai_side} exact ranked strike only when contract data is available",
            "levels": scenario_levels(spot, .8 if ai_side == "CE" else -.8, ai_side), "data_trust": round(dq),
            "freshness": "LIVE", "decision_rule": "one current index-option thesis",
        })

    # One current thesis per symbol. Highest-quality surviving candidate wins.
    candidates.sort(key=lambda x: (x.get("quality", 0), abs(num(x.get("change_pct")) or 0)), reverse=True)
    unique: List[Dict[str, Any]] = []
    seen_symbols = set()
    for x in candidates:
        sym = x.get("symbol")
        if sym in seen_symbols:
            continue
        seen_symbols.add(sym)
        unique.append(x)

    # Correlation-aware independent shortlist: one stock per sector plus index.
    independent: List[Dict[str, Any]] = []
    seen_groups = set()
    for x in unique:
        key = (x.get("sector"), x.get("side")) if x.get("kind") == "STOCK" else (x.get("symbol"), x.get("side"))
        if key in seen_groups:
            continue
        seen_groups.add(key)
        if x.get("lifecycle") == "FILTERED — SMALL MOVE":
            continue
        independent.append(x)
        if len(independent) >= 5:
            break

    ready = [x for x in unique if x.get("quality", 0) >= 80 and x.get("lifecycle") in ("READY", "TRIGGER READY")]
    state = _market_state(bull, bear, [num(x.get("change_pct")) or 0 for x in rows])
    market_bias = "BULLISH" if breadth_ratio > .25 else "BEARISH" if breadth_ratio < -.25 else "MIXED"
    top = independent[0] if independent else None
    funnel = {
        "observed": len(raw), "live": len(rows), "interesting": sum(x.get("quality", 0) >= 60 for x in unique),
        "high_quality": len(ready), "independent": len(independent), "best": (top or {}).get("symbol"),
        "small_move_filtered": sum(x.get("lifecycle") == "FILTERED — SMALL MOVE" for x in unique),
    }
    return {
        "version": "53.0", "generated_at": time.time(), "market_state": state, "market_bias": market_bias,
        "breadth_score": round(breadth_ratio * 100), "funnel": funnel,
        "coverage": {"live_stocks": len(rows), "configured_universe": len(raw), "sectors": len(groups)},
        "breadth": {"bullish": bull, "bearish": bear, "neutral": max(0, len(rows)-bull-bear)},
        "best_now": independent[:3], "independent": independent, "queue": unique[:24], "alert_candidates": ready[:8],
        "decision": {"action": "WAIT" if not top or top.get("quality", 0) < 80 else "REVIEW SETUP",
                     "reason": "No A/A+ independent setup passes the V53 clarity gate." if not top or top.get("quality", 0) < 80 else f"{top['symbol']} {top['side']} is the strongest independent current thesis.",
                     "data_safe": bool(rows)},
        "policy": {"execution_enabled": False, "orders_enabled": False, "pnl_enabled": False,
                   "quality_not_profit_probability": True, "one_thesis_per_stock": True,
                   "stock_cash_labels": "BUY/SELL only", "option_requires_strike": True,
                   "tiny_trade_floor_points": 2.0,
                   "coverage_note": "Ranks the connected live universe only; it does not guarantee complete NSE/F&O coverage or opportunity detection."},
    }

from __future__ import annotations
from typing import Any, Dict, List
import time


def safe(v, default=0.0):
    try:
        if v is None or v == "": return default
        return float(v)
    except Exception:
        return default

def clamp(x, lo, hi): return max(lo, min(hi, x))

def grade(q: float) -> str:
    if q >= 88: return "A+"
    if q >= 80: return "A"
    if q >= 70: return "B+"
    if q >= 60: return "B"
    return "WATCH"

def lifecycle(q: float, live: bool=True) -> str:
    if not live: return "DATA WAIT"
    if q >= 82: return "READY"
    if q >= 70: return "BUILDING"
    return "WATCH"

def scenario_levels(spot: float, chg: float, side: str) -> Dict[str, Any]:
    if not spot: return {"entry_trigger": None, "sl": None, "t1": None, "t2": None, "note":"Spot unavailable"}
    risk_pct = clamp(0.35 + abs(chg) * 0.10, 0.35, 0.85)
    trigger_pct = clamp(0.08 + abs(chg) * 0.025, 0.08, 0.20)
    s = 1 if side == "CE" else -1
    entry = spot * (1 + s * trigger_pct/100)
    sl = entry * (1 - s * risk_pct/100)
    t1 = entry * (1 + s * (risk_pct*1.4)/100)
    t2 = entry * (1 + s * (risk_pct*2.2)/100)
    return {
        "entry_trigger": round(entry,2), "sl": round(sl,2), "t1": round(t1,2), "t2": round(t2,2),
        "risk_pct": round(risk_pct,2),
        "note":"Volatility-scaled analytical scenario levels; confirm with live structure before use."
    }

def build_opportunity_radar(market: Dict[str,Any], ai: Dict[str,Any], smart_money: Dict[str,Any]) -> Dict[str,Any]:
    rows = [x for x in (market.get("sector_heatmap") or []) if x and x.get("live") and x.get("change_pct") is not None and x.get("ltp")]
    groups: Dict[str,List[Dict[str,Any]]] = {}
    for r in rows: groups.setdefault(r.get("sector") or "Other", []).append(r)
    sector_avg = {k: sum(safe(x.get("change_pct")) for x in v)/max(1,len(v)) for k,v in groups.items()}
    candidates=[]
    for r in rows:
        chg=safe(r.get("change_pct")); side="CE" if chg>0 else "PE" if chg<0 else "WAIT"
        if side=="WAIT": continue
        sec=r.get("sector") or "Other"; secavg=sector_avg.get(sec,0.0)
        aligned=(chg>0 and secavg>0) or (chg<0 and secavg<0)
        momentum=clamp(abs(chg)*24,0,45)
        sector_score=16 if aligned else 4
        breadth_bonus=clamp(abs(secavg)*8,0,12)
        q=clamp(38+momentum+sector_score+breadth_bonus,0,96)
        reasons=[f"{chg:+.2f}% live move", f"{sec} sector {secavg:+.2f}%"]
        if aligned: reasons.append("sector confirmation")
        if abs(chg)>=1: reasons.append("momentum expansion")
        levels=scenario_levels(safe(r.get("ltp")),chg,side)
        candidates.append({
            "symbol":r.get("symbol"),"kind":"STOCK","sector":sec,"ltp":r.get("ltp"),"change_pct":round(chg,2),
            "side":side,"quality":round(q),"grade":grade(q),"lifecycle":lifecycle(q,True),"reasons":reasons,
            "option_preference":f"{side} • ATM/near-ATM • liquid contract only","levels":levels,
            "data_trust":100,"freshness":"LIVE"
        })
    # Active index candidate uses the app's deeper AI stack.
    code=market.get("active_underlying") or "NIFTY"; spot=safe(market.get("spot")); ai_side=ai.get("side") or "WAIT"
    if ai_side in ("CE","PE"):
        aq=clamp(safe(ai.get("confidence"),0),0,100)
        # confidence here is retained as the existing app's confluence-quality score, not profit probability.
        candidates.append({
            "symbol":code,"kind":"INDEX","sector":"INDEX","ltp":spot,"change_pct":None,"side":ai_side,
            "quality":round(aq),"grade":grade(aq),"lifecycle":lifecycle(aq,True),
            "reasons":[str(x) for x in (ai.get("reasons") or [])[:4]] or ["multi-agent index confluence"],
            "option_preference":f"{ai_side} • {safe((ai.get('top_contract') or {}).get('strike'),0):.0f} preferred" if ai.get('top_contract') else f"{ai_side} • ranked index option",
            "levels":scenario_levels(spot,0.8 if ai_side=='CE' else -0.8,ai_side),"data_trust":round(safe(ai.get("data_quality"),90)),"freshness":"LIVE"
        })
    candidates.sort(key=lambda x:(x.get("quality",0), abs(safe(x.get("change_pct")))), reverse=True)
    top=candidates[:12]
    bullish=sum(1 for x in rows if safe(x.get("change_pct"))>0); bearish=sum(1 for x in rows if safe(x.get("change_pct"))<0)
    alerts=[x for x in top if x["quality"]>=80]
    return {
        "version":"31.0","generated_at":time.time(),"coverage":{"live_stocks":len(rows),"configured_universe":len(market.get("sector_heatmap") or []),"sectors":len(groups)},
        "breadth":{"bullish":bullish,"bearish":bearish,"neutral":max(0,len(rows)-bullish-bearish)},
        "best_now":top[:5],"queue":top,"alert_candidates":alerts,
        "policy":{"execution_enabled":False,"orders_enabled":False,"pnl_enabled":False,"quality_not_profit_probability":True,
                  "note":"Scanner ranks live analytical setups. It cannot guarantee that every market opportunity is detected."}
    }
